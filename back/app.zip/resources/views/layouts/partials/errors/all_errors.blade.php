<script>
    jQuery.sound_path = '{{ asset('ap/sound') }}/';
</script>

@include('layouts.partials.errors.form_errors')

@include('layouts.partials.errors.msg_err')