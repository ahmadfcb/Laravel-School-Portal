

<?php $__env->startSection("breadcrumb"); ?>
    <li>Dashboard</li>
    <li>Student Fee</li>
    <li><?php echo e($title); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("page_header"); ?>
    <i class="fa fa-fw fa-money"></i>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.partials.datatable", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection("content"); ?>
    <div class="row">
        
		<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <!-- Widget ID (each widget will need unique ID)-->
            <div class="jarviswidget" id="wid-id-0">
                <header><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
                    <span class="widget-icon"> <i class="fa fa-search"></i> </span>
                    <h2>Statics</h2>

                </header>

                <!-- widget div-->
                <div>

                    <!-- widget edit box -->
                    <div class="jarviswidget-editbox">
                        <!-- This area used as dropdown edit box -->
                        <input class="form-control" type="text">
                    </div>
                    <!-- end widget edit box -->

                    <!-- widget content -->
                    <div class="widget-body">

        		<table class="table table-striped table-bordered table-hover dtable">
                                <thead>
                                    <tr>
									<th>Absent </th>
									<th>Present</th>
									</tr>
									<tbody>
										<tr>
											<td><?php echo e($totals_ab); ?></td>
											<td><?php echo e($totals_pr); ?></td>
												
										</tr>
									</tbody>
									
									</thead></table>                
									<br>

											<table width="100%" class="table table-striped table-bordered  "  >
                                <thead>
                                    <tr>
									<th>Section</th>
									<th>Male</th>
									<th>Female</th>
									
									</tr>
									<tbody>
									 <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<tr>
											<td><?php echo e($branch->name); ?></td>
											<td><?php  echo $ssm[$branch->id] ?></td>
											<td><?php  echo $ssf[$branch->id] ?></td>
											
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>		
									
												
										</tr>
									</tbody>
									
									</thead></table>                
		
		
                    </div>
                    <!-- end widget content -->
                </div>
                <!-- end widget div -->
            </div>
            <!-- end widget -->
        </article>
		
		<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <!-- Widget ID (each widget will need unique ID)-->
            <div class="jarviswidget" id="wid-id-0">
                <header>
                    <span class="widget-icon"> <i class="fa fa-search"></i> </span>
                    <h2>Search </h2>

                </header>

                <!-- widget div-->
                <div>

                    <!-- widget edit box -->
                    <div class="jarviswidget-editbox">
                        <!-- This area used as dropdown edit box -->
                        <input class="form-control" type="text">
                    </div>
                    <!-- end widget edit box -->

                    <!-- widget content -->
                    <div class="widget-body">

                        <form action="<?php echo e(url()->current()); ?>" method="get">
                            <div class="row">
                                <div class="col-sm-2">
                                    <div class="form-group">
                                        <label>Branch</label>
                                        <select class="form-control branch" name="branch_id">
                                            <option value="">Select Branch</option>
                                            <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($branch->id); ?>" <?php echo e($branch->id == $branch_id ? 'selected':''); ?>><?php echo e($branch->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-sm-2">
                                    <div class="form-group">
                                        <label>Current Class</label>
                                        <select class="form-control current_class school_class" name="current_class_id">
                                            <option value="">Select Current Class</option>

                                            <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($class->id); ?>" <?php echo e($class->id == $current_class_id ? 'selected':''); ?>><?php echo e($class->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-sm-2">
                                    <div class="form-group">
                                        <label>Section</label>
                                        <select class="form-control section" name="section_id">
                                            <option value="">Select Section</option>

                                            <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($section->id); ?>" <?php echo e($section->id == $section_id ? 'selected':''); ?>><?php echo e($section->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-sm-2">
                                    <div class="form-group">
                                        <label>Total Arrear >=</label>
                                        <input type="number" class="form-control" name="greater_than_equal" value="<?php echo e($greater_than_equal ?? ''); ?>" min="0" placeholder="Total Arrear >=">
                                    </div>
                                </div>

                                <div class="col-sm-2">
                                    <div class="form-group">
                                        <label>Total Arrear <=</label>
                                        <input type="number" class="form-control" name="less_than_equal" value="<?php echo e($less_than_equal ?? ''); ?>" min="0" placeholder="Total Arrear <=">
                                    </div>
                                </div>

                                <div class="col-sm-2">
                                    <div>Defaulter Report type</div>

                                    <div class="radio">
                                        <label>
                                            <input type="radio" name="defaulter_report_type" value="current_month" <?php echo e($defaulter_report_type == 'current_month' ? 'checked' : ''); ?>> Current Month
                                        </label>

                                        <label>
                                            <input type="radio" name="defaulter_report_type" value="overall" <?php echo e($defaulter_report_type == 'overall' ? 'checked' : ''); ?>> Overall
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <div class="form-actions">
                                <button type="submit" class="btn btn-primary">Search</button>
                            </div>
                        </form>

                    </div>
                    <!-- end widget content -->
                </div>
                <!-- end widget div -->
            </div>
            <!-- end widget -->
        </article>

        <article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="jarviswidget" id="wid-id-1">
                <header>
                    <span class="widget-icon"> <i class="fa fa-users"></i> </span>
                    <h2>Defaulters (<?php echo e($defaulter_report_type == 'overall' ? "Overall" : "Current Month"); ?>) </h2>

                </header>
                <div>
                    <div class="jarviswidget-editbox">
                        <input class="form-control" type="text">
                    </div>

                    <div class="widget-body no-padding">

                        <div class="table-responsive">
                            <table class="table table-striped table-bordered table-hover dtable">
                                <thead>
                                    <tr>
                                        <th colspan="11" class="text-center">Total: <?php echo e($totals['students']['total']); ?>, Male: <?php echo e($totals['students']['male']); ?>, Female: <?php echo e($totals['students']['male']); ?></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th>Total</th>
                                        <th><?php echo e($totals['totalArrears']); ?></th>
                                        <th><?php echo e($totals['currentMonthArrears']); ?></th>
                                    </tr>
                                    <tr>
                                        <th class="text-center">Select
                                            <br><input type="checkbox" class="select_all_checkbox_js" data-target-selector=".select_checkbox_js">
                                        </th>
                                        <th>PIN</th>
                                        <th>Reg#</th>
                                        <th>Name</th>
                                        <th>Father's Name</th>
                                        <th>Father's Cell</th>
                                        <th>Branch</th>
                                        <th>Class</th>
                                        <th>Section</th>
                                        <th>Total Arrears</th>
                                        <th>Current Month Arrears</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="text-center">
                                                <input type="checkbox" class="select_checkbox_js" name="student_ids[]" value="<?php echo e($student->id); ?>">
                                            </td>
                                            <td><?php echo e($student->pin); ?></td>
                                            <td><?php echo e($student->reg_no); ?></td>
                                            <td>
                                                <span class="visible-print"><?php echo e($student->name); ?></span>
                                                <a class="hidden-print" href="<?php echo e(route('dashboard.student_fee.receive_fee', ['student' => $student->id])); ?>"><?php echo e($student->name); ?></a>
                                            </td>
                                            <td><?php echo e($student->fatherRecord->name ?? ''); ?></td>
                                            <td><?php echo e($student->fatherRecord->mobile ?? ''); ?></td>
                                            <td><?php echo e($student->branch->name ?? ''); ?></td>
                                            <td><?php echo e($student->currentClass->name ?? ''); ?></td>
                                            <td><?php echo e($student->section->name ?? ''); ?></td>
                                            <td><?php echo e($student->totalArrears); ?></td>
                                            <td><?php echo e($student->currentMonthArrears); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th>Total</th>
                                        <th><?php echo e($totals['totalArrears']); ?></th>
                                        <th><?php echo e($totals['currentMonthArrears']); ?></th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                        
                        <div class="form-actions">
                            <button type="button" class="btn btn-primary form_checkbox_value_btn" data-checkbox-selector=".select_checkbox_js" data-url="<?php echo e(route('dashboard.sms.manual')); ?>" data-param-name="student_ids" data-entity="students">Send SMS</button>
                        </div>

                    </div>
                </div>
            </div>
        </article>
		
		
		
		
		
		
		



<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <!-- Widget ID (each widget will need unique ID)-->
            <div class="jarviswidget" id="wid-id-0">
                <header>
                    <span class="widget-icon"> <i class="fa fa-table"></i> </span>
                    <h2>Filter </h2>

                </header>

                <!-- widget div-->
                <div>

                    <!-- widget edit box -->
                    <div class="jarviswidget-editbox">
                        <!-- This area used as dropdown edit box -->
                        <input class="form-control" type="text">
                    </div>
                    <!-- end widget edit box -->

                    <!-- widget content -->
                    <div class="widget-body">
                        <form action="<?php echo e(url()->current()); ?>" method="get">
                            <fieldset>
                                <div class="row">
                                    <div class="col-sm-2">
                                        <div class="form-group">
                                            <label>Branch</label>
                                            <select name="branch_id_at" class="form-control">
                                                <option value="">---Select Branch---</option>

                                                <?php $__currentLoopData = $branches_at; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($branch->id); ?>" <?php echo e(( $branch_id == $branch->id ? "selected" : "" )); ?>><?php echo e($branch->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-sm-2">
                                        <div class="form-group">
                                            <label>Class</label>
                                            <select name="class_id_at" class="form-control">
                                                <option value="">---Select Class---</option>

                                                <?php $__currentLoopData = $classes_at; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($class->id); ?>" <?php echo e(( $class_id_at == $class->id ? "selected" : "" )); ?>><?php echo e($class->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-sm-2">
                                        <div class="form-group">
                                            <label>Section</label>
                                            <select name="section_id_at" class="form-control">
                                                <option value="">---Select Section---</option>

                                                <?php $__currentLoopData = $sections_at; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($section->id); ?>" <?php echo e(( $section_id == $section->id ? "selected" : "" )); ?>><?php echo e($section->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-sm-2">
                                        <div class="form-group">
                                            <label>Attendance Date</label>
                                            <input type="text" class="form-control datepicker" name="attendance_date_at" value="<?php echo e($attendance_date_at ?? ''); ?>" placeholder="Attendance Date" data-dateformat="dd-mm-yy" data-maxdate="+0d">
                                        </div>
                                    </div>

                                    <div class="col-sm-4">
                                        <p>Attendance Types</p>
                                        <div class="checkbox">
                                            <?php $__currentLoopData = $student_attendance_types_at; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student_attendance_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <label class="checkbox-inline">
                                                    <input type="checkbox" name="student_attendance_type_ids_at[]" value="<?php echo e($student_attendance_type->id); ?>" <?php echo e(collect($student_attendance_type_ids_at)->contains($student_attendance_type->id) ? "checked" : ""); ?>> <?php echo e($student_attendance_type->name); ?>

                                                </label>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>

                                    <?php if(!empty($branch_id_at) && !empty($class_id_at)): ?>
                                        <div class="clearfix"></div>

                                        <div class="col-sm-2">
                                            <div class="form-group">
                                                <label>Date From</label>
                                                <input type="text" class="form-control datepicker" name="date_from_at" value="<?php echo e($date_from_at ?? ''); ?>" placeholder="Date From" data-dateformat="dd-mm-yy" data-maxdate="+0d">
                                            </div>
                                        </div>

                                        <div class="col-sm-2">
                                            <div class="form-group">
                                                <label>Date To</label>
                                                <input type="text" class="form-control datepicker" name="date_to" value="<?php echo e($date_to_at ?? ''); ?>" placeholder="Date To" data-dateformat="dd-mm-yy" data-maxdate="+0d">
                                            </div>
                                        </div>

                                        <?php $__currentLoopData = $student_attendance_types_at; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student_attendance_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <input type="hidden" name="attendance_filter_counts[<?php echo e($loop->index); ?>][student_attendance_type_id]" value="<?php echo e($student_attendance_type->id); ?>">
                                            <div class="col-sm-2">
                                                <b><?php echo e($student_attendance_type->name); ?></b>
                                                <div class="form-group">
                                                    <label>Greater than equal to</label>
                                                    <input type="number" class="form-control" name="attendance_filter_counts[<?php echo e($loop->index); ?>][greater_than_equal]" value="<?php echo e($attendance_filter_counts[$loop->index]['greater_than_equal']); ?>">
                                                </div>

                                                <div class="form-group">
                                                    <label>Greater than equal to</label>
                                                    <input type="number" class="form-control" name="attendance_filter_counts[<?php echo e($loop->index); ?>][less_than_equal]" value="<?php echo e($attendance_filter_counts[$loop->index]['less_than_equal']); ?>">
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>
                            </fieldset>

                            <div class="form-actions">
                                <button type="submit" class="btn btn-primary">Filter</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </article>		
		
		  <?php if( !empty($branches_statistics) ): ?>
            <article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <!-- Widget ID (each widget will need unique ID)-->
                <div class="jarviswidget" id="wid-id-1">
                    <header>
                        <span class="widget-icon"> <i class="fa fa-table"></i> </span>
                        <h2>Branches Statistics </h2>

                    </header>

                    <!-- widget div-->
                    <div>

                        <!-- widget edit box -->
                        <div class="jarviswidget-editbox">
                            <!-- This area used as dropdown edit box -->
                            <input class="form-control" type="text">
                        </div>
                        <!-- end widget edit box -->

                        <!-- widget content -->
                        <div class="widget-body no-padding">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>Branch</th>

                                            <?php $__currentLoopData = $student_attendance_types_selected; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student_attendance_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <th><?php echo e($student_attendance_type->name); ?></th>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            <th>Total</th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php $__currentLoopData = $branches_statistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branches_statistic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <a class="hidden-print" href="<?php echo e(route('dashboard.student_attendance.report', ['branch_id' => $branches_statistic['branch']->id])); ?>"><?php echo e($branches_statistic['branch']->name); ?></a>
                                                    <span class="visible-print"><?php echo e($branches_statistic['branch']->name); ?></span>
                                                </td>

                                                <?php $__currentLoopData = $branches_statistic['attendance_types']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <td><?php echo e($attendance_type['count']); ?></td>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                <td><?php echo e($branches_statistic['total']); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>

                                    <tfoot>
                                        <tr>
                                            <th colspan="<?php echo e(( count($branches_statistic['attendance_types']) + 2 )); ?>" class="text-center">
                                                <?php $__currentLoopData = $branches_statistics_totals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $branches_statistics_total): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <b><?php echo e($k); ?>:</b> <?php echo e($branches_statistics_total); ?><?php echo e($loop->last ? '' : ','); ?>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </article>
        <?php endif; ?>

        <?php if( !empty($class_statistics) ): ?>
            <article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <!-- Widget ID (each widget will need unique ID)-->
                <div class="jarviswidget" id="wid-id-2">
                    <header>
                        <span class="widget-icon"> <i class="fa fa-table"></i> </span>
                        <h2>Classes Statistics </h2>

                    </header>

                    <!-- widget div-->
                    <div>

                        <!-- widget edit box -->
                        <div class="jarviswidget-editbox">
                            <!-- This area used as dropdown edit box -->
                            <input class="form-control" type="text">
                        </div>
                        <!-- end widget edit box -->

                        <!-- widget content -->
                        <div class="widget-body no-padding">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>Class</th>

                                            <?php $__currentLoopData = $student_attendance_types_selected; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student_attendance_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <th><?php echo e($student_attendance_type->name); ?></th>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            <th>Total</th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php $__currentLoopData = $class_statistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class_statistic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <a href="<?php echo e(route('dashboard.student_attendance.report', [ 'branch_id' => $branch_id, 'class_id' => $class_statistic['class']->id ])); ?>"><?php echo e($class_statistic['class']->name); ?></a>
                                                </td>

                                                <?php $__currentLoopData = $class_statistic['attendance_types']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <td><?php echo e($attendance_type['count']); ?></td>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                <td><?php echo e($class_statistic['total']); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>

                                    <tfoot>
                                        <tr>
                                            <th colspan="<?php echo e(2 + count($class_statistic['attendance_types'])); ?>" class="text-center">
                                                <?php $__currentLoopData = $class_statistics_totals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $class_statistics_total): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <b><?php echo e(ucwords($k)); ?>:</b> <?php echo e($class_statistics_total); ?><?php echo e($loop->last ? '' : ','); ?>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </article>
        <?php endif; ?>

        <?php if( !empty($students_at) ): ?>
            <article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <!-- Widget ID (each widget will need unique ID)-->
                <div class="jarviswidget" id="wid-id-3">
                    <header>
                        <span class="widget-icon"> <i class="fa fa-table"></i> </span>
                        <h2>Students </h2>

                    </header>

                    <!-- widget div-->
                    <div>

                        <!-- widget edit box -->
                        <div class="jarviswidget-editbox">
                            <!-- This area used as dropdown edit box -->
                            <input class="form-control" type="text">
                        </div>
                        <!-- end widget edit box -->

                        <!-- widget content -->
                        <div class="widget-body no-padding">
                            <div class="table-responsive">
                                <table class="table table-bordered table-bordered dtable" data-datatable-message-top="<?php $__currentLoopData = $student_statistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <b><?php echo e(ucwords($key)); ?>:</b> <?php echo e($value); ?><?php echo e($loop->last === true ? '' : ', '); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>">
                                    <thead>
                                        <tr>
                                            <th class="text-center">
                                                Select<br><input type="checkbox" class="select_all_checkbox_js" data-target-selector=".select_checkbox_js">
                                            </th>
                                            <th>PIN</th>
                                            <th>Sr. No.</th>
                                            <th>Name</th>
                                            <th>Father's Name</th>
                                            <th>Attendance<br>
                                                <small>(<?php echo e($attendance_date_at); ?>)</small>
                                            </th>
                                           <?php /*?> <th>Date Range Counts</th><?php */?>
                                        </tr>
                                    </thead>

                                    <tbody>
									
                                        <?php $__currentLoopData = $students_at; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="text-center">
                                                    <input type="checkbox" class="select_checkbox_js" name="student_ids[]" value="<?php echo e($student->id); ?>">
                                                </td>
                                                <td><?php echo e($student->pin); ?></td>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td>
                                                    <a href="<?php echo e(route('dashboard.student_attendance.student_report', ['student' => $student->id])); ?>">
                                                        <?php echo e($student->name); ?>

                                                    </a>
                                                </td>
                                                <td><?php echo e($student->fatherRecord->name ?? ''); ?></td>
                                                <td><?php echo e(($student->attandences->isNotEmpty() ? $student->attandences->first()->studentAttendanceType->name : "Attendance not marked")); ?></td>
                                              <?php /*?>  <td>
                                                    @foreach($student->range_attendance_counts as $range_attendance_count)
                                                        <div>{{ $range_attendance_count['student_attendance_type']->name }}(s): {{ $range_attendance_count['count'] }}</div>
                                                    @endforeach
                                                </td><?php */?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>

                                    <tfoot>
                                        <tr>
                                            <th colspan="6" class="text-center">
                                                <?php $__currentLoopData = $student_statistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <b><?php echo e(ucwords($key)); ?>:</b> <?php echo e($value); ?><?php echo e($loop->last === true ? '' : ', '); ?>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>

                            <div class="form-actions">
                                <button type="button" class="btn btn-primary form_checkbox_value_btn" data-checkbox-selector=".select_checkbox_js" data-url="<?php echo e(route('dashboard.sms.manual')); ?>" data-param-name="student_ids" data-entity="students">Send SMS</button>
                            </div>
                        </div>
                    </div>
                </div>
            </article>
        <?php endif; ?>
		
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.main", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>