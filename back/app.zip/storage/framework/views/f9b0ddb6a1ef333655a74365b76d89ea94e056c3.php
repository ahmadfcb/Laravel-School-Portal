

<?php $__env->startSection("breadcrumb"); ?>
    <li>Dashboard</li>
    <li><?php echo e($title); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("page_header"); ?>
    <i class="fa fa-fw fa-money"></i>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.partials.datatable", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection("content"); ?>

    <div class="row">
        <div class="col-xs-12" style="margin-bottom: 10px;">
            <a href="<?php echo e($redirectUrl); ?>" class="btn btn-default">
                <i class="fa fa-arrow-left"></i>
                Back
            </a>
        </div>

        <article class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
            <!-- Widget ID (each widget will need unique ID)-->
            <div class="jarviswidget" id="wid-id-1">

                <header>
                    <span class="widget-icon"> <i class="fa fa-money"></i> </span>
                    <h2>Receive Fee </h2>

                </header>

                <!-- widget div-->
                <div>

                    <!-- widget edit box -->
                    <div class="jarviswidget-editbox">
                        <!-- This area used as dropdown edit box -->
                        <input class="form-control" type="text">
                    </div>
                    <!-- end widget edit box -->

                    <!-- widget content -->
                    <div class="widget-body">
                        <form class="confirm_resubmission" action="<?php echo e(route('dashboard.student_fee.receive_fee', ['student' => $student->id])); ?>" method="post">
                            <?php echo e(csrf_field()); ?>


                            <fieldset>
                                <?php $__currentLoopData = $feeTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feeType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="fee_types[<?php echo e($loop->index); ?>][fee_type_id]" value="<?php echo e($feeType->id); ?>">

                                    <div class="form-group">
                                        <label><?php echo e($feeType->name); ?> <small>(Arrear/Balance: <?php echo e($feeType->studentFeeArrears[0]->arrear ?? 0); ?>)</small></label>
                                        <input type="text" class="form-control" name="fee_types[<?php echo e($loop->index); ?>][value]" value="<?php echo e(old("fee_types[{$loop->iteration}][value]")); ?>" min="0" placeholder="<?php echo e($feeType->name); ?>">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </fieldset>

                            <div class="form-actions">
                                <button type="submit" class="btn btn-primary" name="btn_name" value="save">Save</button>
                                <button type="submit" class="btn btn-primary" name="btn_name" value="print">Save and Print</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </article>

        <?php if( \Auth::user()->userHasPrivilege('student_fee_remission') ): ?>
            <article class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                <!-- Widget ID (each widget will need unique ID)-->
                <div class="jarviswidget" id="wid-id-2">

                    <header>
                        <span class="widget-icon"> <i class="fa fa-money"></i> </span>
                        <h2>Fee Remission </h2>

                    </header>

                    <!-- widget div-->
                    <div>

                        <!-- widget edit box -->
                        <div class="jarviswidget-editbox">
                            <!-- This area used as dropdown edit box -->
                            <input class="form-control" type="text">
                        </div>
                        <!-- end widget edit box -->

                        <!-- widget content -->
                        <div class="widget-body">
                            <form class="confirm_resubmission" action="<?php echo e(route('dashboard.student_fee.fee_remission', ['student' => $student->id])); ?>" method="post">
                                <?php echo e(csrf_field()); ?>


                                <fieldset>
                                    <?php $__currentLoopData = $feeTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feeType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <input type="hidden" name="fee_types[<?php echo e($loop->index); ?>][fee_type_id]" value="<?php echo e($feeType->id); ?>">

                                        <div class="form-group">
                                            <label><?php echo e($feeType->name); ?> <small>(Arrear/Balance: <?php echo e($feeType->studentFeeArrears[0]->arrear ?? 0); ?>)</small></label>
                                            <input type="text" class="form-control" name="fee_types[<?php echo e($loop->index); ?>][remission_amount]" value="<?php echo e(old("fee_types[{$loop->iteration}][remission_amount]")); ?>" min="0" placeholder="<?php echo e($feeType->name); ?> Remission" <?php echo ( isset($feeType->studentFeeArrears[0]->arrear) && intval($feeType->studentFeeArrears[0]->arrear) > 0 ? '' : 'readonly title="Fee remission not available for fee which are already paid in advance"' ); ?> rel="tooltip">
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </fieldset>

                                <div class="form-actions">
                                    <button type="submit" class="btn btn-primary">Save Remission</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </article>
        <?php endif; ?>

        <article class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
            <!-- Widget ID (each widget will need unique ID)-->
            <div class="jarviswidget" id="wid-id-1">

                <header>
                    <span class="widget-icon"> <i class="fa fa-money"></i> </span>
                    <h2>User Details </h2>

                </header>

                <!-- widget div-->
                <div>

                    <!-- widget edit box -->
                    <div class="jarviswidget-editbox">
                        <!-- This area used as dropdown edit box -->
                        <input class="form-control" type="text">
                    </div>
                    <!-- end widget edit box -->

                    <!-- widget content -->
                    <div class="widget-body">

                        <?php if(!empty($student->image)): ?>
                            <div class="text-center" style="margin-bottom: 10px;">
                                <img src="<?php echo e(Storage::url($student->image)); ?>" style="max-height: 100px; max-width: 100px;">
                            </div>
                        <?php endif; ?>

                        <table class="table">
                            <tbody>
                                <tr>
                                    <th>Pin</th>
                                    <td><?php echo e($student->pin); ?></td>
                                </tr>

                                <tr>
                                    <th>Reg#</th>
                                    <td><?php echo e($student->reg_no); ?></td>
                                </tr>

                                <tr>
                                    <th>Name</th>
                                    <td><?php echo e($student->name); ?></td>
                                </tr>

                                <tr>
                                    <th>Branch</th>
                                    <td><?php echo e($student->branch->name ?? "N/A"); ?></td>
                                </tr>

                                <tr>
                                    <th>Class</th>
                                    <td><?php echo e($student->currentClass->name ?? "N/A"); ?></td>
                                </tr>

                                <tr>
                                    <th>Section</th>
                                    <td><?php echo e($student->section->name ?? "N/A"); ?></td>
                                </tr>

                                <tr>
                                    <th>Payable Student's<br>Monthly Fee</th>
                                    <th class="text-danger"><?php echo e($payableFee); ?></th>
                                </tr>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </article>

        <div class="clearfix"></div>

        <article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <!-- Widget ID (each widget will need unique ID)-->
            <div class="jarviswidget" id="wid-id-2">

                <header>
                    <span class="widget-icon"> <i class="fa fa-money"></i> </span>
                    <h2>Transactions </h2>

                </header>

                <!-- widget div-->
                <div>

                    <!-- widget edit box -->
                    <div class="jarviswidget-editbox">
                        <!-- This area used as dropdown edit box -->
                        <input class="form-control" type="text">
                    </div>
                    <!-- end widget edit box -->

                    <!-- widget content -->
                    <div class="widget-body no-padding">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped dtable">
                                <thead>
                                    <tr>
                                        <th>Datetime</th>
                                        <th>Transaction<br>Description</th>
                                        <th></th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php $__currentLoopData = $studentFeeTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentFeeTransaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td style="vertical-align: middle;">
                                                <?php if( Auth::user()->userHasPrivilege('student_fee_transaction_view_single') ): ?>
                                                    <a href="<?php echo e(route('dashboard.student_fee.transaction', ['studentFeeTransaction' => $studentFeeTransaction->id])); ?>" title="Click to open transaction print page" rel="tooltip">
                                                        <?php echo e($studentFeeTransaction->created_at->toDayDateTimeString()); ?>

                                                    </a>
                                                <?php else: ?>
                                                    <?php echo e($studentFeeTransaction->created_at->toDayDateTimeString()); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($studentFeeTransaction->description ?? ''); ?></td>
                                            <td style="padding: 0;">
                                                <table class="table">
                                                    <thead>
                                                        <tr>
                                                            <th>Fee Type</th>
                                                            <th>Received</th>
                                                            <th>Added to Student Account</th>
                                                            <th>Remission</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $studentFeeTransaction->records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentFeeTransactionRecord): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td><?php echo e($studentFeeTransactionRecord->studentFeeType->name ?? ''); ?></td>
                                                                <td><?php echo e($studentFeeTransactionRecord->debit); ?></td>
                                                                <td><?php echo e($studentFeeTransactionRecord->credit); ?></td>
                                                                <td><?php echo e($studentFeeTransactionRecord->remission); ?></td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </td>
                                            <td class="vertical_align_middle text-center">
                                                <?php if( Auth::user()->userHasPrivilege('student_fee_transaction_delete')): ?>
                                                    <a href="<?php echo e(route('dashboard.student_fee.transaction.delete', ['studentFeeTransaction' => $studentFeeTransaction->id])); ?>" class="btn btn-danger btn-xs delete-confirm-model" title="Delete this transaction" rel="tooltip">
                                                        <i class="fa fa-trash-o"></i>
                                                    </a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </article>
    </div>

    <div class="text-center">
        <p>All transactions can be printed from this page. To print individual transaction details, click on the <i>date time</i> of the respective transaction.</p>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.main", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>