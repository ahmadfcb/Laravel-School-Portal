<?php $__env->startSection("breadcrumb"); ?>
    <li>Dashboard</li>
    <li><?php echo e($title); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("page_header"); ?>
    <i class="fa fa-fw fa-chain-broken"></i>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection("content"); ?>
    <div class="row">
        <article class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
            <!-- Widget ID (each widget will need unique ID)-->
            <div class="jarviswidget" id="wid-id-0">
                <header>
                    <span class="widget-icon"> <i class="fa fa-chain-broken"></i> </span>
                    <h2>Details </h2>

                </header>

                <!-- widget div-->
                <div>

                    <!-- widget edit box -->
                    <div class="jarviswidget-editbox">
                        <!-- This area used as dropdown edit box -->
                        <input class="form-control" type="text">
                    </div>
                    <!-- end widget edit box -->

                    <!-- widget content -->
                    <div class="widget-body">

                        <?php if(!empty($student->image)): ?>
                            <div class="text-center" style="margin-bottom: 10px;">
                                <img src="<?php echo e(Storage::url($student->image)); ?>" style="max-height: 100px; max-width: 100px;">
                            </div>
                        <?php endif; ?>

                        <table class="table">
                            <tbody>
                                <tr>
                                    <th>Pin</th>
                                    <td><?php echo e($student->pin); ?></td>
                                </tr>

                                <tr>
                                    <th>Reg#</th>
                                    <td><?php echo e($student->reg_no); ?></td>
                                </tr>

                                <tr>
                                    <th>Name</th>
                                    <td><?php echo e($student->name); ?></td>
                                </tr>

                                <tr>
                                    <th>Branch</th>
                                    <td><?php echo e($student->branch->name ?? "N/A"); ?></td>
                                </tr>

                                <tr>
                                    <th>Class</th>
                                    <td><?php echo e($student->currentClass->name ?? "N/A"); ?></td>
                                </tr>

                                <tr>
                                    <th>Section</th>
                                    <td><?php echo e($student->section->name ?? "N/A"); ?></td>
                                </tr>
                            </tbody>
                        </table>

                        <form action="<?php echo e(route('dashboard.student_withdraw', ['student' => $student->id])); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="redirect_back" value="<?php echo e(back()->getTargetUrl()); ?>">

                            <fieldset>
                                <div class="form-group">
                                    <label>Comment</label>
                                    <textarea class="form-control" name="comment" rows="5"><?php echo e(old('comment')); ?></textarea>
                                </div>

                                <div class="form-group">
                                    <div>Certificate Issued?</div>
                                    <div class="radio">
                                        <label>
                                            <input type="radio" name="certificate_issued" value="1" <?php echo e(old('certificate_issued', '0') == '1' ? 'checked' : ''); ?>> Yes
                                        </label>

                                        <label>
                                            <input type="radio" name="certificate_issued" value="0" <?php echo e(old('certificate_issued', '0') == '0' ? 'checked' : ''); ?>> No
                                        </label>
                                    </div>
                                </div>
                            </fieldset>

                            <div class="form-actions">
                                <button type="submit" class="btn btn-primary">Withdraw</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </article>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.main", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>