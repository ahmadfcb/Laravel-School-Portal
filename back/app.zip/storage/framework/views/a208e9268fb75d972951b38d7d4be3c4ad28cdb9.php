
<?php if( !empty( session('msg') ) ): ?>
    <?php if( is_array( session( 'msg' ) ) ): ?>
        <?php $__currentLoopData = session('msg'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <script>
                jQuery( function () {
                    jQuery.smallBox( {
                        title: "SUCCESS",
                        content: "<?php echo $msg; ?>",
                        color: "#749e74",
                        timeout: 10000,
                        icon: "fa fa-check"
                    } );
                } );
            </script>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <script>
            jQuery( function () {
                jQuery.smallBox( {
                    title: "SUCCESS",
                    content: "<?php echo session('msg'); ?>",
                    color: "#749e74",
                    timeout: 10000,
                    icon: "fa fa-check"
                } );
            } );
        </script>
    <?php endif; ?>
<?php endif; ?>


<?php if( !empty( session( 'err' ) ) ): ?>
    <?php if( is_array( session( 'err' ) ) ): ?>
        <?php $__currentLoopData = session( 'err' ); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <script>
                jQuery( function () {
                    jQuery.smallBox( {
                        title: "ERROR",
                        content: "<?php echo $err; ?>",
                        color: "#c46b6a",
                        timeout: 10000,
                        icon: "fa fa-warning"
                    } );
                } );
            </script>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <script>
            jQuery( function () {
                jQuery.smallBox( {
                    title: "ERROR",
                    content: "<?php echo session('err'); ?>",
                    color: "#c46b6a",
                    timeout: 10000,
                    icon: "fa fa-warning"
                } );
            } );
        </script>
    <?php endif; ?>
<?php endif; ?>


    
        
            
                
            

            
        
    



    
        
            
                
            

            
        
    

