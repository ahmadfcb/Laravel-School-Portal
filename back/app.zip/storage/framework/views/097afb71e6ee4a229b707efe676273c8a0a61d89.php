

<?php $__env->startSection("breadcrumb"); ?>
    <li>Dashboard</li>
    <li>Student Fee</li>
    <li><?php echo e($title); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("page_header"); ?>
    <i class="fa fa-fw fa-money"></i>
    <?php echo e($title); ?>

    <?php if($date_diff_days > 0): ?>
        -
        <small>(<?php echo e($date_diff); ?> interval)</small>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.partials.datatable", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection("content"); ?>
    <div class="row">
        <!-- NEW WIDGET START -->
        <article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <!-- Widget ID (each widget will need unique ID)-->
            <div class="jarviswidget" id="wid-id-0">
                <header>
                    <span class="widget-icon"> <i class="fa fa-money"></i> </span>
                    <h2>Filter Transactions </h2>

                </header>

                <!-- widget div-->
                <div>

                    <!-- widget edit box -->
                    <div class="jarviswidget-editbox">
                        <!-- This area used as dropdown edit box -->
                        <input class="form-control" type="text">
                    </div>
                    <!-- end widget edit box -->

                    <!-- widget content -->
                    <div class="widget-body">
                        <form action="<?php echo e(url()->current()); ?>" method="get">
                            <fieldset>
                                <div class="row">
                                    <div class="col-sm-2">
                                        <div class="form-group">
                                            <label>Branch</label>
                                            <select class="form-control branch" name="branch_id">
                                                <option value="">Select Branch</option>
                                                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($branch->id); ?>" <?php echo e($branch->id == $branch_id ? 'selected':''); ?>><?php echo e($branch->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-sm-2">
                                        <div class="form-group">
                                            <label>Current Class</label>
                                            <select class="form-control current_class school_class" name="current_class_id">
                                                <option value="">Select Current Class</option>

                                                <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($class->id); ?>" <?php echo e($class->id == $current_class_id ? 'selected':''); ?>><?php echo e($class->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-sm-2">
                                        <div class="form-group">
                                            <label>Section</label>
                                            <select class="form-control section" name="section_id">
                                                <option value="">Select Section</option>

                                                <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($section->id); ?>" <?php echo e($section->id == $section_id ? 'selected':''); ?>><?php echo e($section->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-sm-2">
                                        <div class="form-group">
                                            <label>Date From</label>
                                            <input type="text" class="form-control datepicker" name="date_from" value="<?php echo e(old('date_from', $date_from->format('d-m-Y'))); ?>" placeholder="Date From" data-dateformat="dd-mm-yy">
                                        </div>
                                    </div>
                                    <div class="col-sm-2">
                                        <div class="form-group">
                                            <label>Date To</label>
                                            <input type="text" class="form-control datepicker" name="date_to" value="<?php echo e(old('date_to', $date_to->format('d-m-Y'))); ?>" placeholder="Date To" data-dateformat="dd-mm-yy">
                                        </div>
                                    </div>
                                    <div class="col-sm-2">
                                        <p>Restrict Transactions Type</p>

                                        <div>
                                            <div class="checkbox">
                                                <label>
                                                    <input type="checkbox" class="checkbox style-0" name="add_transaction" value="1" <?php echo e($add_transaction == 1 ? 'checked' : ''); ?>>
                                                    <span>Added Arrears</span>
                                                </label>
                                            </div>
                                            <div class="checkbox">
                                                <label>
                                                    <input type="checkbox" class="checkbox style-0" name="deposit_transactions" value="1" <?php echo e($deposit_transactions == 1 ? 'checked' : ''); ?>>
                                                    <span>Paid by Students</span>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </fieldset>

                            <div class="form-actions">
                                <button type="submit" class="btn btn-primary">Filter</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </article>

        <?php if($statistics['show_branches_stats'] === true || $statistics['show_class_stats'] === true || $statistics['show_section_stats'] === true): ?>
            <article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <!-- Widget ID (each widget will need unique ID)-->
                <div class="jarviswidget" id="wid-id-2" data-widget-collapsed="<?php echo e(($expand_stats === true ? 'false' : 'true')); ?>">
                    <header>
                        <span class="widget-icon"> <i class="fa fa-bar-chart"></i> </span>
                        <h2>Statistics </h2>

                    </header>

                    <div>

                        <!-- widget edit box -->
                        <div class="jarviswidget-editbox">
                            <!-- This area used as dropdown edit box -->
                            <input class="form-control" type="text">
                        </div>
                        <!-- end widget edit box -->

                        <!-- widget content -->
                        <div class="widget-body no-padding">
                            <div class="table-responsive">
                                <?php if($statistics['show_branches_stats'] === true): ?>
                                    <table class="table table-bordered table-striped dtable">
                                        <thead>
                                            <tr>
                                                <th>Branch</th>
                                                <th>Students Paid <small>(Within selected interval)</small></th>
                                                <th>Added to Students' accounts <small>(Within selected interval)</small></th>
                                                <th>Total Arrears (Overall)</th>
                                            </tr>
                                        </thead>

                                        <tbody>
                                            <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <a href="<?php echo e(route('dashboard.student_fee.transaction.all', ['branch_id' => $branch->id, 'date_from' => $date_from->format('d-m-Y'), 'date_to' => $date_to->format('d-m-Y'), 'expand_stats' => 1])); ?>">
                                                            <?php echo e($branch->name); ?>

                                                        </a>
                                                    </td>
                                                    <td><?php echo e($branch->debit); ?></td>
                                                    <td><?php echo e($branch->credit); ?></td>
                                                    <td><?php echo e($branch->arrear); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                <?php elseif($statistics['show_class_stats'] === true): ?>
                                    <table class="table table-bordered table-striped dtable">
                                        <thead>
                                            <tr>
                                                <th>Class</th>
                                                <th>Students Paid <small>(Within selected interval)</small></th>
                                                <th>Added to Students' accounts <small>(Within selected interval)</small></th>
                                                <th>Total Arrears (Overall)</th>
                                            </tr>
                                        </thead>

                                        <tbody>
                                            <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <a href="<?php echo e(route('dashboard.student_fee.transaction.all', ['branch_id' => ($branch_id ?? ''), 'current_class_id' => $class->id, 'date_from' => $date_from->format('d-m-Y'), 'date_to' => $date_to->format('d-m-Y'), 'expand_stats' => 1])); ?>">
                                                            <?php echo e($class->name); ?>

                                                        </a>
                                                    </td>
                                                    <td><?php echo e($class->debit); ?></td>
                                                    <td><?php echo e($class->credit); ?></td>
                                                    <td><?php echo e($class->arrear); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                <?php elseif($statistics['show_section_stats'] === true): ?>
                                    <table class="table table-bordered table-striped dtable">
                                        <thead>
                                            <tr>
                                                <th>Section</th>
                                                <th>Students Paid <small>(Within selected interval)</small></th>
                                                <th>Added to Students' accounts <small>(Within selected interval)</small></th>
                                                <th>Total Arrears (Overall)</th>
                                            </tr>
                                        </thead>

                                        <tbody>
                                            <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <a class="hidden-print" href="<?php echo e(route('dashboard.student_fee.transaction.all', ['branch_id' => ($branch_id ?? ''), 'current_class_id' => ($class_id ?? ''), 'section_id' => $section->id, 'date_from' => $date_from->format('d-m-Y'), 'date_to' => $date_to->format('d-m-Y'), 'expand_stats' => 1])); ?>">
                                                            <?php echo e($section->name); ?>

                                                        </a>
                                                        <span class="visible-print">
                                                            <?php echo e($section->name); ?>

                                                        </span>
                                                    </td>
                                                    <td><?php echo e($section->debit); ?></td>
                                                    <td><?php echo e($section->credit); ?></td>
                                                    <td><?php echo e($section->arrear); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                <?php endif; ?>
                            </div>

                        </div>
                    </div>
                </div>
            </article>
        <?php endif; ?>

        <article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <!-- Widget ID (each widget will need unique ID)-->
            <div class="jarviswidget" id="wid-id-1">
                <header>
                    <span class="widget-icon"> <i class="fa fa-money"></i> </span>
                    <h2>Transactions </h2>

                </header>

                <!-- widget div-->
                <div>

                    <!-- widget edit box -->
                    <div class="jarviswidget-editbox">
                        <!-- This area used as dropdown edit box -->
                        <input class="form-control" type="text">
                    </div>
                    <!-- end widget edit box -->

                    <!-- widget content -->
                    <div class="widget-body no-padding">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped dtable">
                                <thead>
                                    <tr>
                                        <th colspan="7" class="text-center">Totals</th>
                                        <th><?php echo e($totals['credit']); ?></th>
                                        <th><?php echo e($totals['debit']); ?></th>
                                        <th><?php echo e($totals['total_fee_arrears']); ?></th>
                                        <th></th>
                                    </tr>

                                    <tr>
                                        <th>PIN</th>
                                        <th>Datetime</th>
                                        <th>Name</th>
                                        <th>Branch</th>
                                        <th>Class</th>
                                        <th>Section</th>
                                        <th>Transaction Description</th>
                                        <th>Added Arrears</th>
                                        <th>Paid by Students</th>
                                        <th>Overall Arrears</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $studentFeeTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentFeeTransaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($studentFeeTransaction->student->pin); ?></td>
                                            <td class="vertical_align_middle">
                                                <?php if( Auth::user()->userHasPrivilege('student_fee_transaction_view_single') ): ?>
                                                    <a class="no_url_render" href="<?php echo e(route('dashboard.student_fee.transaction', ['studentFeeTransaction' => $studentFeeTransaction->id])); ?>" title="Transaction detail page" rel="tooltip">
                                                        <?php echo e($studentFeeTransaction->created_at->toDayDateTimeString()); ?>

                                                    </a>
                                                <?php else: ?>
                                                    <?php echo e($studentFeeTransaction->created_at->toDayDateTimeString()); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td class="vertical_align_middle">
                                                <?php if( Auth::user()->userHasPrivilege('receive_fee') ): ?>
                                                    <a class="no_url_render" href="<?php echo e(route('dashboard.student_fee.receive_fee', ['student' => $studentFeeTransaction->student_id])); ?>" title="Student's fee receive page" rel="tooltip">
                                                        <?php echo e($studentFeeTransaction->student->name); ?>

                                                    </a>
                                                <?php else: ?>
                                                    <?php echo e($studentFeeTransaction->student->name); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td class="vertical_align_middle"><?php echo e($studentFeeTransaction->student->branch->name ?? ''); ?></td>
                                            <td class="vertical_align_middle"><?php echo e($studentFeeTransaction->student->currentClass->name ?? ''); ?></td>
                                            <td class="vertical_align_middle"><?php echo e($studentFeeTransaction->student->section->name ?? ''); ?></td>
                                            <td><?php echo e($studentFeeTransaction->description ?? ''); ?></td>
                                            <td><?php echo e($studentFeeTransaction->records->sum('credit')); ?></td>
                                            <td><?php echo e($studentFeeTransaction->records->sum('debit')); ?></td>
                                            <td><?php echo e($studentFeeTransaction->student->total_fee_arrears); ?></td>
                                            <td class="vertical_align_middle text-center">
                                                <?php if( Auth::user()->userHasPrivilege('student_fee_transaction_delete')): ?>
                                                    <a href="<?php echo e(route('dashboard.student_fee.transaction.delete', ['studentFeeTransaction' => $studentFeeTransaction->id])); ?>"
                                                            class="btn btn-danger btn-xs delete-confirm-model no_url_render" title="Delete this transaction" rel="tooltip">
                                                        <i class="fa fa-trash-o"></i>
                                                    </a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>Totals</th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><?php echo e($totals['credit']); ?></th>
                                        <th><?php echo e($totals['debit']); ?></th>
                                        <th><?php echo e($totals['total_fee_arrears']); ?></th>
                                        <th></th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </article>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.main", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>