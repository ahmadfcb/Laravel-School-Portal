<script>
    jQuery.sound_path = '<?php echo e(asset('ap/sound')); ?>/';
</script>

<?php echo $__env->make('layouts.partials.errors.form_errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('layouts.partials.errors.msg_err', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>