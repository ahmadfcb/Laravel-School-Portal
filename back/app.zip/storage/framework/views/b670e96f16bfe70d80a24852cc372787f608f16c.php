

<?php $__env->startSection("breadcrumb"); ?>
    <li>Dashboard</li>
    <li><?php echo e($title); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("page_header"); ?>
    <i class="fa fa-fw fa-book"></i>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.partials.datatable", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection("content"); ?>

    <div class="row">
        <?php if(Auth::user()->userHasPrivilege('class_add')): ?>
            <article class="col-xs-12 col-sm-5 col-md-5 col-lg-4">
                <!-- Widget ID (each widget will need unique ID)-->
                <div class="jarviswidget" id="wid-id-0">

                    <header>
                        <span class="widget-icon"> <i class="fa fa-book"></i> </span>
                        <h2>Add Class </h2>

                    </header>

                    <!-- widget div-->
                    <div>

                        <!-- widget edit box -->
                        <div class="jarviswidget-editbox">
                            <!-- This area used as dropdown edit box -->
                            <input class="form-control" type="text">
                        </div>
                        <!-- end widget edit box -->

                        <!-- widget content -->
                        <div class="widget-body">

                            <form action="<?php echo e(route('dashboard.class')); ?>" method="post">
                                <?php echo e(csrf_field()); ?>


                                
                                <?php if($classEdit->id !== null): ?>
                                    <?php echo e(method_field('PUT')); ?>

                                    <input type="hidden" name="id" value="<?php echo e($classEdit->id); ?>">
                                <?php endif; ?>

                                <fieldset>
                                    <div class="form-group">
                                        <label>Class</label>
                                        <input type="text" class="form-control" name="name" value="<?php echo e(old('name', ($classEdit->name ?: "") )); ?>" placeholder="Class Name">
                                    </div>

                                    <div class="form-group">
                                        <label>Fee</label>
                                        <input type="number" class="form-control" name="fee" value="<?php echo e(old('fee', ($classEdit->fee ?: ""))); ?>" placeholder="Class Fee">
                                    </div>
                                    
                                </fieldset>

                                <div class="form-actions">
                                    <button type="submit" class="btn btn-primary">
                                        <?php if($classEdit->id === null): ?>
                                            Create
                                        <?php else: ?>
                                            Update
                                        <?php endif; ?>
                                    </button>
                                </div>
                            </form>

                        </div>
                        <!-- end widget content -->
                    </div>
                    <!-- end widget div -->
                </div>
                <!-- end widget -->
            </article>
        <?php endif; ?>

        <article class="col-xs-12 col-sm-7 col-md-7 col-lg-8">
            <!-- Widget ID (each widget will need unique ID)-->
            <div class="jarviswidget" id="wid-id-1">
                <header>
                    <span class="widget-icon"> <i class="fa fa-book"></i> </span>
                    <h2>Classes </h2>

                </header>

                <!-- widget div-->
                <div>

                    <!-- widget edit box -->
                    <div class="jarviswidget-editbox">
                        <!-- This area used as dropdown edit box -->
                        <input class="form-control" type="text">
                    </div>
                    <!-- end widget edit box -->

                    <!-- widget content -->
                    <div class="widget-body no-padding">

                        <div class="table-responsive">
                            <table class="table table-striped table-bordered table-hover dtable">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <td>Fee</td>
                                        <th>Action</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($class->name); ?></td>
                                            <td><?php echo e($class->fee); ?></td>

                                            <td>
                                                <?php if(Auth::user()->userHasPrivilege('class_edit')): ?>
                                                    <a href="<?php echo e(route('dashboard.class', ['classEdit' => $class->id])); ?>" class="btn btn-default btn-xs" rel="tooltip" title="Edit class">
                                                        <i class="fa fa-pencil"></i>
                                                    </a>
                                                <?php endif; ?>

                                                <?php if(Auth::user()->userHasPrivilege('class_delete')): ?>
                                                    <a href="<?php echo e(route('dashboard.class.delete', ['class' => $class->id])); ?>"
                                                            class="btn btn-danger btn-xs confirm-action-model" rel="tooltip" title="Delete class"
                                                            data-body="Do you really want to delete this class?<br>It will be deleted after being removed from all the students.<br>No student will be deleted because of this.<br>Although it is recommended, you should edit it rather than deleting.">
                                                        <i class="fa fa-trash-o"></i>
                                                    </a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                    <!-- end widget content -->
                </div>
                <!-- end widget div -->
            </div>
            <!-- end widget -->
        </article>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.main", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>