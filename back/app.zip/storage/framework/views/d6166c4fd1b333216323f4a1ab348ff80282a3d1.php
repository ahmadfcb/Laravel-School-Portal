

<?php $__env->startSection("content"); ?>

    <div class="student_fee_transaction_print">
        <div class="student_fee_transaction_print_single">
            <div class="row" style="font-size: 80%">
                <div class="col-xs-6 text-left">Receipt ID: <?php echo e($studentFeeTransaction->id); ?></div>
                <div class="col-xs-6 text-right">Date: <?php echo e($studentFeeTransaction->created_at->format('d-m-Y')); ?></div>
            </div>

            <h3 class="student_fee_transaction_print_single_heading">Fee Transaction Details</h3>

            <table class="table">
                <tbody>
                    <tr>
                        <th>PIN</th>
                        <td><?php echo e($studentFeeTransaction->student->pin); ?></td>
                    </tr>
                    <tr>
                        <th>Name</th>
                        <td><?php echo e($studentFeeTransaction->student->name ?? ''); ?></td>
                    </tr>
                    <tr>
                        <th>Father's Name</th>
                        <td><?php echo e($studentFeeTransaction->student->fatherRecord->name ?? ''); ?></td>
                    </tr>
                    <tr>
                        <th>Branch</th>
                        <td><?php echo e($studentFeeTransaction->student->branch->name ?? ''); ?></td>
                    </tr>
                    <tr>
                        <th>Class</th>
                        <td><?php echo e($studentFeeTransaction->student->currentClass->name ?? ''); ?></td>
                    </tr>
                    <tr>
                        <th>Section</th>
                        <td><?php echo e($studentFeeTransaction->student->section->name ?? ''); ?></td>
                    </tr>
                    <tr>
                        <th>Category</th>
                        <td><?php echo e($studentFeeTransaction->student->category->name ?? ''); ?></td>
                    </tr>
                </tbody>
            </table>

            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Fee</th>
                        <th>Added to account <small>(Rs.)</small></th>
                        <th>Paid <small>(Rs.)</small></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $studentFeeTransaction->records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentFeeTransactionRecord): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($studentFeeTransactionRecord->studentFeeType->name ?? ''); ?></td>
                            <td><?php echo e($studentFeeTransactionRecord->credit ?? 0); ?></td>
                            <td><?php echo e($studentFeeTransactionRecord->debit ?? 0); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th>Total</th>
                        <th><?php echo e($studentFeeTransaction->records->sum('credit') ?? 0); ?></th>
                        <th><?php echo e($studentFeeTransaction->records->sum('debit') ?? 0); ?></th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.blank", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>