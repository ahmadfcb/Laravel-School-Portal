<?php $__env->startSection("content"); ?>

    <div class="student_card_print">
        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="student_card_container">
                <div class="student_card_inner_container">
                    <h3 class="student_card_heading"><?php echo e(config('app.name')); ?></h3>

                    <div class="student_card_row">
                        <div class="student_card_left">
                            <img class="student_card_img" src="<?php echo e(Storage::url($student->image)); ?>" alt="<?php echo e($student->name); ?>">
                        </div>

                        <div class="student_card_right">
                            <div><b>PIN:</b> <span style="font-size: 105%; font-weight: bold; text-decoration: underline;"><?php echo e($student->pin); ?></span></div>
                            <div><b>Name:</b> <?php echo e($student->name); ?></div>
                            <div><b>Father's Name:</b> <?php echo e($student->fatherRecord->name ?? ''); ?></div>
                            <div><b>CNIC:</b> <?php echo e($student->cnic); ?></div>
                            <div><b>Branch:</b> <?php echo e($student->branch->name ?? ''); ?></div>
                            <div><b>Class:</b> <?php echo e($student->currentClass->name ?? ''); ?></div>
                            <div><b>Section:</b> <?php echo e($student->section->name ?? ''); ?></div>
                        </div>
                    </div>

                    <div class="student_card_footer">
                        <div class="student_card_footer_left">Print Date: <?php echo e($print_date); ?></div>

                        <div class="student_card_footer_right">Principal's Sig. : _________________ </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.blank", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>