<?php $__env->startSection("form"); ?>
    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('password.email')); ?>" id="login-form" class="smart-form client-form" method="post">
        <header>
            Reset Password
        </header>

        <?php echo e(csrf_field()); ?>


        <fieldset>

            <section>
                <label class="label">E-mail</label>
                <label class="input"> <i class="icon-append fa fa-user"></i>
                    <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>
                    <b class="tooltip tooltip-top-right"><i class="fa fa-user txt-color-teal"></i> Please enter email address/username</b>
                </label>

                <?php if($errors->has('email')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                <?php endif; ?>
            </section>

        </fieldset>
        <footer>
            <button type="submit" class="btn btn-primary">Send Password Reset Link</button>
        </footer>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush("body"); ?>
    <script type="text/javascript">
        $( function () {
            // Validation
            $( "#login-form" ).validate( {
                // Rules for form validation
                rules: {
                    email: {
                        required: true,
                        email: true
                    }
                },

                // Messages for form validation
                messages: {
                    email: {
                        required: 'Please enter your email address',
                        email: 'Please enter a VALID email address'
                    }
                },

                // Do not change code below
                errorPlacement: function ( error, element ) {
                    error.insertAfter( element.parent() );
                }
            } );
        } );
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make("layouts.login", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>