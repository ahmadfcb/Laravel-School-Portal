

<?php $__env->startSection("breadcrumb"); ?>
    <li>Dashboard</li>
    <li>Student Fee Fine</li>
    <li><?php echo e($title); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("page_header"); ?>
    <i class="fa fa-fw fa-money"></i>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.partials.datatable", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection("content"); ?>
    <div class="row">
        <!-- NEW WIDGET START -->
        <article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <!-- Widget ID (each widget will need unique ID)-->
            <div class="jarviswidget" id="wid-id-0">
                <header>
                    <span class="widget-icon"> <i class="fa fa-search"></i> </span>
                    <h2><?php echo e($title); ?> </h2>

                </header>

                <!-- widget div-->
                <div>

                    <!-- widget edit box -->
                    <div class="jarviswidget-editbox">
                        <!-- This area used as dropdown edit box -->
                        <input class="form-control" type="text">
                    </div>
                    <!-- end widget edit box -->

                    <!-- widget content -->
                    <div class="widget-body">
                        <form action="<?php echo e(url()->current()); ?>" method="get">
                            <fieldset>
                                <div class="row">
                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label>Branch</label>
                                            <select name="branch_id" class="form-control">
                                                <option value="">---Select Branch---</option>

                                                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($branch->id); ?>" <?php echo e(( $branch_id == $branch->id ? "selected" : "" )); ?>><?php echo e($branch->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label>Class</label>
                                            <select name="class_id" class="form-control">
                                                <option value="">---Select Class---</option>

                                                <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($class->id); ?>" <?php echo e(( $class_id == $class->id ? "selected" : "" )); ?>><?php echo e($class->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label>Section</label>
                                            <select name="section_id" class="form-control">
                                                <option value="">---Select Section---</option>

                                                <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($section->id); ?>" <?php echo e(( $section_id == $section->id ? "selected" : "" )); ?>><?php echo e($section->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </fieldset>

                            <div class="form-actions">
                                <button type="submit" class="btn btn-primary">Filter</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </article>

        <article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <!-- Widget ID (each widget will need unique ID)-->
            <div class="jarviswidget" id="wid-id-1">

                <header>
                    <span class="widget-icon"> <i class="fa fa-users"></i> </span>
                    <h2>Students </h2>

                </header>

                <!-- widget div-->
                <div>

                    <!-- widget edit box -->
                    <div class="jarviswidget-editbox">
                        <!-- This area used as dropdown edit box -->
                        <input class="form-control" type="text">
                    </div>
                    <!-- end widget edit box -->

                    <!-- widget content -->
                    <div class="widget-body no-padding">
                        <form action="<?php echo e(url()->current()); ?>" method="post">
                            <?php echo e(csrf_field()); ?>


                            <div class="table-responsive">
                                <table class="table table-striped table-bordered dtable">
                                    <thead>
                                        <tr>
                                            <th colspan="<?php echo e(7 + ($permissions['can_edit_extra_discount'] === true ? 1 : 0) + (count($studentFeeTypes))); ?>" class="text-center">Total Students: <?php echo e($totals['total_students']); ?>, Total Male: <?php echo e($totals['total_male']); ?>, Total Female: <?php echo e($totals['total_female']); ?></th>
                                        </tr>

                                        <tr>
                                            <th>PIN</th>
                                            <th>Name</th>
                                            <th>Father's Name</th>
                                            <th>Branch</th>
                                            <th>Class</th>
                                            <th>Section</th>
                                            <th>Picture</th>

                                            <?php if($permissions['can_edit_extra_discount'] === true): ?>
                                                <th>Extra Discount</th>
                                            <?php endif; ?>

                                            <?php $__currentLoopData = $studentFeeTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentFeeType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <th><?php echo e($studentFeeType->name); ?></th>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($student->pin); ?></td>
                                                <td><?php echo e($student->name); ?></td>
                                                <td><?php echo e($student->fatherRecord->name ?? ''); ?></td>
                                                <td><?php echo e($student->branch->name ?? ''); ?></td>
                                                <td><?php echo e($student->currentClass->name ?? ''); ?></td>
                                                <td><?php echo e($student->section->name ?? ''); ?></td>
                                                <td>
                                                    <img style="width: 100%; max-width: 100px; max-height: 100px;" src="<?php echo e(Storage::url($student->image)); ?>" alt="<?php echo e($student->name); ?>" title="<?php echo e($student->name); ?>">
                                                </td>

                                                <?php if($permissions['can_edit_extra_discount'] === true): ?>
                                                    <td>
                                                        <div>
                                                            <input type="text" class="form-control student_payable_monthly_fee_input" name="students[<?php echo e($loop->index); ?>][extra_discount]" value="<?php echo e($student->extra_discount ?? 0); ?>" data-monthly-fee-without-extra-discount="<?php echo e($student->monthly_fee_without_extra_discount); ?>" required>
                                                            <div>Student's Payable Monthly Fee: <span class="student_payable_monthly_fee"><?php echo e($student->payable_monthly_fee); ?></span></div>
                                                        </div>
                                                    </td>
                                                <?php endif; ?>

                                                <input type="hidden" name="students[<?php echo e($loop->index); ?>][student_id]" value="<?php echo e($student->id); ?>">
                                                <?php $__currentLoopData = $student->student_fee_arrears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student_fee_arrear): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <td>
                                                        <input type="hidden" name="students[<?php echo e($loop->parent->index); ?>][fee_arrears][<?php echo e($loop->index); ?>][fee_type_id]" value="<?php echo e($student_fee_arrear['feeTypeId']); ?>">
                                                        <input type="number" class="form-control" style="max-width: 150px;" name="students[<?php echo e($loop->parent->index); ?>][fee_arrears][<?php echo e($loop->index); ?>][arrear]" value="<?php echo e(old("students[{$loop->parent->index}][fee_arrears][{$loop->index}][arrear]") ?? ($student_fee_arrear['value'] === null ? 0 : $student_fee_arrear['value'])); ?>" placeholder="<?php echo e($student_fee_arrear['feeType']); ?> Arrears">
                                                    </td>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                            <div class="form-actions">
                                <button type="submit" class="btn btn-primary">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </article>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('body'); ?>
    <script>
        jQuery( function ( $ ) {
            var calculate_replace_payable_fee = function ( ele ) {
                ele = $( ele );

                var extra_discount = parseInt( ele.val() ),
                    monthly_fee_without_extra_discount = parseInt( ele.data( 'monthly-fee-without-extra-discount' ) ),
                    output_selector = ele.parent().find( '.student_payable_monthly_fee' ),
                    amount = 0;

                if ( !isNaN( extra_discount ) ) {
                    amount = monthly_fee_without_extra_discount - extra_discount;
                    amount = (amount < 0 ? 0 : amount);

                    output_selector.text( amount );
                }
            };

            // running on events
            $( '.student_payable_monthly_fee_input' ).on( 'change keyup', function () {
                calculate_replace_payable_fee( this );
            } );
        } );
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make("layouts.main", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>