<?php $__env->startSection("breadcrumb"); ?>
    <li>Dashboard</li>
    <li>User</li>
    <li>Privileges</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("page_header"); ?>
    <i class="fa fa-shield"></i> Privileges
<?php $__env->stopSection(); ?>

<?php $__env->startSection("page_subtitle", "{$user->name} ({$user->email})"); ?>

<?php echo $__env->make("layouts.partials.datatable", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection("content"); ?>
    <div class="row">

        <!-- NEW WIDGET START -->
        <article class="col-xs-12 col-sm-8 col-md-8 col-lg-8">

            <!-- Widget ID (each widget will need unique ID)-->
            <div class="jarviswidget" id="wid-id-1">

                <header>
                    <span class="widget-icon"> <i class="fa fa-shield"></i> </span>
                    <h2>Privileges </h2>

                </header>

                <!-- widget div-->
                <div>

                    <!-- widget edit box -->
                    <div class="jarviswidget-editbox">
                        <!-- This area used as dropdown edit box -->
                        <input class="form-control" type="text">
                    </div>
                    <!-- end widget edit box -->

                    <!-- widget content -->
                    <div class="widget-body">

                        <form action="<?php echo e(route('dashboard.users.privilege', ['user' => $user->id])); ?>" method="post">
                            <?php echo e(csrf_field()); ?>


                            <div class="table-responsive">
                                <table class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>Sr.</th>
                                            <th>Privilege Title</th>
                                            <th>Status
                                                <input type="checkbox" class="select_all_checkbox_js" data-target-selector=".select_checkbox_js" rel="tooltip" title="Select/Unselect all privileges">
                                            </th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php $__currentLoopData = $privileges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $privilege): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($privilege->title); ?></td>
                                                <td>
                                                    <label>
                                                        <input class="select_checkbox_js" type="checkbox" name="user_privileges[]" value="<?php echo e($privilege->id); ?>" <?php echo e(( $user_privileges->contains('id', '=', $privilege->id) ? "checked" : "" )); ?>>
                                                    </label>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                            <div class="form-actions">
                                <button class="btn btn-primary" type="submit">Update</button>
                            </div>
                        </form>

                    </div>
                    <!-- end widget content -->

                </div>
                <!-- end widget div -->
            </div>
            <!-- end widget -->

        </article>
        <!-- WIDGET END -->

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.main", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>