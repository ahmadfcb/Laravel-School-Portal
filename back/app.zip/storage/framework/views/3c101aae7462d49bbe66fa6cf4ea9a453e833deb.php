

<?php $__env->startSection("breadcrumb"); ?>
    <li>Dashboard</li>
    <li><?php echo e($title); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("page_header"); ?>
    <i class="fa fa-fw fa-money"></i>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
    <div class="row">
        <!-- NEW WIDGET START -->
        <article class="col-xs-12 col-sm-7 col-md-6 col-lg-5">
            <!-- Widget ID (each widget will need unique ID)-->
            <div class="jarviswidget" id="wid-id-0">

                <header>
                    <span class="widget-icon"> <i class="fa fa-money"></i> </span>
                    <h2><?php echo e($title); ?> </h2>

                </header>

                <!-- widget div-->
                <div>

                    <!-- widget edit box -->
                    <div class="jarviswidget-editbox">
                        <!-- This area used as dropdown edit box -->
                        <input class="form-control" type="text">
                    </div>
                    <!-- end widget edit box -->

                    <!-- widget content -->
                    <div class="widget-body">
                        <form action="<?php echo e(route('dashboard.student_fee.generate')); ?>" method="post" onsubmit="return confirm('Do you want to proceed with fee generation?')">
                            <?php echo e(csrf_field()); ?>

                            
                            <?php if(empty($students_last_fee_generation_date_time)): ?>
                                <p>Fee never generated before</p>
                            <?php else: ?>
                                <p>Last fee generation Time: <?php echo e($students_last_fee_generation_date_time->toDayDateTimeString()); ?></p>
                            <?php endif; ?>
                            
                            <div class="text-center">
                                <button class="btn btn-primary" type="submit">Generate Fee</button>
                            </div>

                            <p class="help-block">You can generate fee as many times as you want, it will be generated only for those student's whose fee hasn't been generated in current month.</p>

                            <?php if($allow_automatic_fee_generate == 0): ?>
                                <p>Automatic Fee Generation has been <b>turned off</b>, which can be turned back on from
                                    <a href="<?php echo e(route('dashboard.option')); ?>">Options page</a>.</p>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>
            </div>
        </article>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.main", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>