<?php $__env->startSection("content"); ?>

    <div class="text-center" style="font-size: 1.2em; margin-bottom: 10px;"><b>Branch:</b> <?php echo e($branch->name); ?>, <b>Class:</b> <?php echo e($current_class->name); ?>, <b>Section:</b> <?php echo e($section->name); ?></div>

    <?php if($students->isEmpty()): ?>
        <p class="text-center text-danger">No student found!</p>
    <?php else: ?>
        <div>
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>PIN</th>
                        <th>Sr</th>
                        <th>Name</th>

                        <?php for($i=0; $i<26; $i++): ?>
                            <th><?php echo e($i + 1); ?></th>
                        <?php endfor; ?>

                        <th>Total</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($student->pin); ?></td>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($student->name); ?></td>

                            <?php for($i=0; $i<26; $i++): ?>
                                <td></td>
                            <?php endfor; ?>

                            <td></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="small text-right">Printed on <?php echo e($printDate->format('d-M-Y')); ?> at <?php echo e($printDate->format('g:i:s A')); ?></div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.blank", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>