<?php if($errors->any()): ?>
    <script>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            jQuery( function () {
                jQuery.smallBox( {
                    title: "ERROR",
                    content: "<?php echo $error; ?>",
                    color: "#c46b6a",
                    timeout: 10000,
                    icon: "fa fa-warning"
                } );
            } );
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </script>
<?php endif; ?>


    
        
            
                
            
            
                
                    
                
            
        
    

