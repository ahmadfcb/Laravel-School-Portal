

<?php $__env->startSection("breadcrumb"); ?>
    <li>Dashboard</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
    <h2>Quick links</h2>

    <?php if(empty($availableButtons)): ?>
        <p><a href=<?php echo e(url('/dashboard/student/admission')); ?> class="btn btn-block btn-default">Admission</a>
		<a href=<?php echo e(url('/dashboard/student')); ?> class="btn btn-block btn-default">Student</a> 
		<a href=<?php echo e(url('/dashboard/attendance-sheet')); ?> class="btn btn-block btn-default">Student Attendance Sheet</a> 
		<a href=<?php echo e(url('/dashboard/student-fee/receive-fee/mass')); ?> class="btn btn-block btn-default">Fee Receive With PIN</a> 
		</p>
    <?php else: ?>
        <div class="row">
            <?php $__currentLoopData = $availableButtons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $availableButton): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-3" style="margin-bottom: 15px;">
                    <a href="<?php echo e($availableButton['link']); ?>" class="btn btn-block btn-default"><?php echo e($availableButton['text']); ?></a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.main", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>