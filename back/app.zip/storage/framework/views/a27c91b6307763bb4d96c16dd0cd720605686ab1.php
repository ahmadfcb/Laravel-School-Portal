

<?php $__env->startSection("breadcrumb"); ?>
    <li>Dashboard</li>
    <li>Attendance</li>
    <li><?php echo e($title); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("page_header"); ?>
    <i class="fa fa-fw fa-table"></i>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.partials.datatable", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection("content"); ?>
    <div class="row">
        <!-- NEW WIDGET START -->
        <article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <!-- Widget ID (each widget will need unique ID)-->
            <div class="jarviswidget" id="wid-id-0">
                <header>
                    <span class="widget-icon"> <i class="fa fa-table"></i> </span>
                    <h2>Filter </h2>

                </header>

                <!-- widget div-->
                <div>

                    <!-- widget edit box -->
                    <div class="jarviswidget-editbox">
                        <!-- This area used as dropdown edit box -->
                        <input class="form-control" type="text">
                    </div>
                    <!-- end widget edit box -->

                    <!-- widget content -->
                    <div class="widget-body">
                        <form action="<?php echo e(url()->current()); ?>" method="get">
                            <fieldset>
                                <div class="row">
                                    <div class="col-sm-3">
                                        <div class="form-group">
                                            <label>Branch</label>
                                            <select name="branch_id" class="form-control">
                                                <option value="">---Select Branch---</option>

                                                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($branch->id); ?>" <?php echo e(( $branch_id == $branch->id ? "selected" : "" )); ?>><?php echo e($branch->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-sm-3">
                                        <div class="form-group">
                                            <label>Class</label>
                                            <select name="class_id" class="form-control">
                                                <option value="">---Select Class---</option>

                                                <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($class->id); ?>" <?php echo e(( $class_id == $class->id ? "selected" : "" )); ?>><?php echo e($class->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-sm-3">
                                        <div class="form-group">
                                            <label>Section</label>
                                            <select name="section_id" class="form-control">
                                                <option value="">---Select Section---</option>

                                                <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($section->id); ?>" <?php echo e(( $section_id == $section->id ? "selected" : "" )); ?>><?php echo e($section->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-sm-3">
                                        <div class="form-group">
                                            <label>Attendance Date</label>
                                            <input type="text" class="form-control datepicker" name="attendance_date" value="<?php echo e($attendance_date ?? ''); ?>" placeholder="Attendance Date" data-dateformat="dd-mm-yy" data-maxdate="+0d" required>
                                        </div>
                                    </div>
                                </div>
                            </fieldset>

                            <div class="form-actions">
                                <button type="submit" class="btn btn-primary">Filter</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </article>


        <?php if(!empty($students)): ?>

            <?php if($attendanceExists): ?>
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 text-center">
                    <p>Students' attendance for <?php echo e($attendance_date); ?> has already been marked!</p>

                    <?php if($attendanceEditPrivilege === false): ?>
                        <p class="text-danger">You don't have privilege to update this attendance.</p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <!-- Widget ID (each widget will need unique ID)-->
                <div class="jarviswidget" id="wid-id-1">
                    <header>
                        <span class="widget-icon"> <i class="fa fa-user"></i> </span>
                        <h2>Students </h2>

                    </header>

                    <!-- widget div-->
                    <div>

                        <!-- widget edit box -->
                        <div class="jarviswidget-editbox">
                            <!-- This area used as dropdown edit box -->
                            <input class="form-control" type="text">
                        </div>
                        <!-- end widget edit box -->

                        <!-- widget content -->
                        <div class="widget-body">
                            <form action="<?php echo e(route('dashboard.student_attendance')); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="attendance_date" value="<?php echo e($attendance_date); ?>">

                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>PIN</th>
                                                <th>Sr. No.</th>
                                                <th>Name</th>
                                                <th>Father's Name</th>
                                                <th>Attendance</th>
                                            </tr>
                                        </thead>

                                        <tbody>
                                            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($student->pin); ?></td>
                                                    <td><?php echo e($loop->iteration); ?></td>
                                                    <td><?php echo e($student->name); ?></td>
                                                    <td><?php echo e($student->fatherRecord->name ?? ''); ?></td>
                                                    <td>
                                                        <input type="hidden" name="students[<?php echo e($loop->index); ?>][student_id]" value="<?php echo e($student->id); ?>">
                                                        <div class="radio">
                                                            <?php $__currentLoopData = $student_attendance_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student_attendance_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <label class="radio-inline">
                                                                    <input type="radio" name="students[<?php echo e($loop->parent->index); ?>][student_attendance_type_id]" value="<?php echo e($student_attendance_type->id); ?>" <?php echo e(( old("students[{$loop->parent->iteration}][student_attendance_type_id]") ?? $student->attendance($attendance_date)->student_attendance_type_id ?? $default_student_attendance_type->value ?? '' ) == $student_attendance_type->id ? "checked" : ""); ?> <?php echo e(($attendanceExists === true && $attendanceEditPrivilege === false ? "disabled" : "")); ?>> <?php echo e($student_attendance_type->name); ?>

                                                                </label>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>

                                <div class="form-actions">
                                    <?php if($attendanceExists): ?>
                                        <?php if($attendanceEditPrivilege === false): ?>
                                            <button type="button" class="btn btn-primary" disabled>You cannot edit Attendance</button>
                                        <?php else: ?>
                                            <button type="submit" class="btn btn-primary">Update Attendance</button>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <button type="submit" class="btn btn-primary" name="attendance_submit" value="mark">Mark Attendance</button>
                                        <button type="submit" class="btn btn-primary" name="attendance_submit" value="mark_and_sms">Mark Attendance & open SMS for absent</button>
                                    <?php endif; ?>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </article>
        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.main", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>