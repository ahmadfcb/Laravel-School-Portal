<?php echo e($slot); ?>

