

<?php $__env->startSection("breadcrumb"); ?>
    <li>Dashboard</li>
    <li><?php echo e($title); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("page_header"); ?>
    <i class="fa fa-fw fa-tags"></i>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.partials.datatable", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection("content"); ?>
    <div class="row">
        <!-- NEW WIDGET START -->
        <article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <!-- Widget ID (each widget will need unique ID)-->
            <div class="jarviswidget" id="wid-id-0">
                <header>
                    <span class="widget-icon"> <i class="fa fa-tags"></i> </span>
                    <h2>Options </h2>

                </header>

                <!-- widget div-->
                <div>

                    <!-- widget edit box -->
                    <div class="jarviswidget-editbox">
                        <!-- This area used as dropdown edit box -->
                        <input class="form-control" type="text">
                    </div>
                    <!-- end widget edit box -->

                    <!-- widget content -->
                    <div class="widget-body">
                        <form action="<?php echo e(route('dashboard.option')); ?>" method="post">
                            <?php echo e(csrf_field()); ?>


                            <fieldset>
                                <div class="row">
                                    <div class="col-sm-4 col-md-3">
                                        <div class="form-group">
                                            <label>Default Student Attendance</label>
                                            <select name="default_student_attendance_type" class="form-control" required>
                                                <option value="">---Select Default Student Attendance---</option>

                                                <?php $__currentLoopData = $student_attendance_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student_attendance_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($student_attendance_type->id); ?>" <?php echo e(( ($default_student_attendance_type->value ?? '') == $student_attendance_type->id ? "selected" : "")); ?>><?php echo e($student_attendance_type->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-sm-4 col-md-3">
                                        <div class="form-group">
                                            <label>Fee Submission Due Date <small>(Of every month)</small></label>
                                            <select name="fee_submission_due_date" class="form-control" required>
                                                <?php for($i=1; $i<=25; $i++): ?>
                                                    <option value="<?php echo e($i); ?>" <?php echo e(old('fee_submission_due_date', $fee_submission_due_date->value) == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                                                <?php endfor; ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-sm-4 col-md-3">
                                        <div class="form-group">
                                            <label>Fine on fee after due date</label>
                                            <input type="number" class="form-control" name="fee_fine_after_due_date" value="<?php echo e(old('fee_fine_after_due_date', $fee_fine_after_due_date->value)); ?>" min="0" placeholder="Fine on fee after due date" required>
                                        </div>
                                    </div>

                                    
                                    <div class="clearfix visible-sm"></div>

                                    <div class="col-sm-4 col-md-3">
                                        <div class="form-group">
                                            <label>Allow automatic fee generation</label>
                                            <select name="allow_automatic_fee_generate" class="form-control" required>
                                                <option value="1" <?php echo e(old('allow_automatic_fee_generate', $allow_automatic_fee_generate->value) == '1' ? 'selected' : ''); ?>>Continue Generating</option>
                                                <option value="0" <?php echo e(old('allow_automatic_fee_generate', $allow_automatic_fee_generate->value) == '0' ? 'selected' : ''); ?>>Pause</option>
                                            </select>
                                        </div>
                                    </div>

                                    
                                    <div class="clearfix visible-md"></div>
                                    <div class="clearfix visible-lg"></div>

                                    <div class="col-sm-4 col-md-3">
                                        <div class="form-group">
                                            <label>SMS template on admission</label>
                                            <select name="sms_on_admission" class="form-control" required>
                                                <option value="">---Select an SMS from template---</option>

                                                <?php $__currentLoopData = $smsTemplates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $smsTemplate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($smsTemplate->id); ?>" <?php echo e(old('sms_on_admission', $sms_on_admission->value) == $smsTemplate->id ? 'selected' : ''); ?>><?php echo e($smsTemplate->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-sm-4 col-md-3">
                                        <div class="form-group">
                                            <label>Default Performance Scale</label>
                                            <select name="default_performance_scale_id" class="form-control" required>
                                                <option value="">---Default Performance Scale---</option>

                                                <?php $__currentLoopData = $performance_scales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $performance_scale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($performance_scale->id); ?>" <?php echo e(old('default_performance_scale_id', $default_performance_scale_id->value) == $performance_scale->id ? 'selected' : ''); ?>><?php echo e($performance_scale->title); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-sm-4 col-md-3">
                                        <label>Send automatic SMS</label>
                                        <div class=""> 
                                            <label>
                                                <input type="checkbox" name="send_automatic_sms" value="1" class="checkbox style-0" <?php echo e(old('send_automatic_sms', $send_automatic_sms->value ?? '') == 1 ? 'checked' : ''); ?>>
                                                <span>Enable</span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </fieldset>

                            <div class="form-actions">
                                <button type="submit" class="btn btn-primary">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </article>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.main", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>