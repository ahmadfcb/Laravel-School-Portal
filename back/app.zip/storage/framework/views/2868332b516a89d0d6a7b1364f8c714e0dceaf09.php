

<?php $__env->startSection("breadcrumb"); ?>
    <li>Dashboard</li>
    <li><?php echo e($title); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("page_header"); ?>
    <i class="fa fa-fw fa-user"></i>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection("content"); ?>
    <div class="row">
        <article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <!-- Widget ID (each widget will need unique ID)-->
            <div class="jarviswidget" id="wid-id-0">
                <header>
                    <span class="widget-icon"> <i class="fa fa-user"></i> </span>
                    <h2>Student Admission form </h2>

                </header>

                <div>

                    <!-- widget edit box -->
                    <div class="jarviswidget-editbox">
                        <!-- This area used as dropdown edit box -->
                        <input class="form-control" type="text">
                    </div>
                    <!-- end widget edit box -->

                    <!-- widget content -->
                    <div class="widget-body">

                        <div class="admission_form">

                            <form action="<?php echo e(route('dashboard.student.admission')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>


                                <?php if( $isInUpdateMode ): ?>
                                    <?php echo e(method_field('put')); ?>

                                    <input type="hidden" name="id" value="<?php echo e($studentEdit->id); ?>">
                                <?php endif; ?>

                                <fieldset>
                                    <div class="row">

                                        <?php if( $isInUpdateMode ): ?>
                                            <div class="col-xs-12 text-center">
                                                <?php if($previousStudent !== null): ?>
                                                    <a href="<?php echo e(route('dashboard.student.admission', ['studentEdit' => $previousStudent->id])); ?>" class="btn btn-default" rel="tooltip" title="Previous Student">
                                                        <i class="fa fa-chevron-left"></i>
                                                    </a>
                                                <?php endif; ?>

                                                <button type="submit" class="btn btn-default" rel="tooltip" title="Save current student record">Update Student</button>

                                                <?php if($nextStudent !== null): ?>
                                                    <a href="<?php echo e(route('dashboard.student.admission', ['studentEdit' => $nextStudent->id])); ?>" class="btn btn-default" rel="tooltip" title="Next Student">
                                                        <i class="fa fa-chevron-right"></i>
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>

                                        <!-- Admission information ends -->
                                        <div class="col-xs-12">
                                            <legend>Admission Information</legend>
                                        </div>

                                        <div class="col-sm-2">
                                            <div class="form-group">
                                                <label>PIN</label>
                                                <input type="text" class="form-control" name="pin" value="<?php echo e(( $studentEdit->pin ?: ( old('pin') ?? $currentMaxPin ) )); ?>" placeholder="PIN">
                                            </div>
                                        </div>
                                        <div class="col-sm-2">
                                            <div class="form-group">
                                                <label>Reg No.</label>
                                                <input type="text" class="form-control" name="reg_no" value="<?php echo e(old('reg_no') ?? $studentEdit->reg_no); ?>" placeholder="Registration Number">
                                            </div>
                                        </div>
                                        <div class="col-sm-2">
                                            <div class="form-group">
                                                <label>Session</label>
                                                <input type="text" class="form-control" name="session" value="<?php echo e(old('session') ?? $studentEdit->session); ?>" placeholder="Session">
                                            </div>
                                        </div>

                                        <div class="col-sm-3">
                                            <div class="form-group">
                                                <label>Date of Admission</label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control datepicker" name="date_of_admission" value="<?php echo e(old('date_of_admission') ?? ( $isInUpdateMode ? ( !empty($studentEdit->date_of_admission) ? $studentEdit->date_of_admission->format('d-m-Y') : "" ) : \Carbon\Carbon::now()->format('d-m-Y') )); ?>" placeholder="Select a date" data-dateformat="dd-mm-yy">
                                                    <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="clearfix"></div>

                                        <div class="col-sm-3">
                                            <div class="form-group">
                                                <label>Class of Admission</label>
                                                <select class="form-control class_of_admission" name="class_of_admission_id">
                                                    <option value="">-Select Class Of Admission-</option>

                                                    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($class->id); ?>" <?php echo e(( ( old('class_of_admission_id') ?? $studentEdit->class_of_admission_id ) == $class->id ? 'selected':'' )); ?>><?php echo e($class->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-sm-3">
                                            <div class="form-group">
                                                <label>Branch</label>
                                                <select class="form-control branch" name="branch_id">
                                                    <option value="">-Select Branch-</option>

                                                    <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($branch->id); ?>" <?php echo e(( ( old('branch_id') ?? $studentEdit->branch_id ) == $branch->id ? "selected" : "" )); ?>><?php echo e($branch->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-sm-3">
                                            <div class="form-group">
                                                <label>Current Class</label>
                                                <select class="form-control current_class school_class" id="current_class_id" name="current_class_id">
                                                    <option value="">-Select Current Class-</option>

                                                    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($class->id); ?>" <?php echo e(( ( old('current_class_id') ?? $studentEdit->current_class_id ) == $class->id ? 'selected':'' )); ?>><?php echo e($class->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-sm-3">
                                            <div class="form-group">
                                                <label>Section</label>
                                                <select class="form-control section" name="section_id">
                                                    <option value="">-Select Section-</option>

                                                    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($section->id); ?>" <?php echo e(( ( old('section_id') ?? $studentEdit->section_id ) == $section->id ? 'selected':'' )); ?>><?php echo e($section->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-sm-3">
                                            <div class="form-group">
                                                <label>Category</label>
                                                <select class="form-control section" id="category_id" name="category_id" rel="tooltip" title="Assigning category will also assign discount of the category to the student.">
                                                    <option value="">-Select Category-</option>

                                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($category->id); ?>" <?php echo e(( ( old('category_id') ?? $studentEdit->category_id ?? '' ) == $category->id ? 'selected':'' )); ?>><?php echo e($category->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-sm-3">
                                            <div class="form-group">
                                                <label>Extra Discount</label>
                                                <input type="text" class="form-control" id="extra_discount" name="extra_discount" value="<?php echo e(old('extra_discount', $studentEdit->extra_discount)); ?>" placeholder="Any extra discount you want to give to student other than the discount available through categories" min="0" rel="tooltip" title="Any extra discount you want to give to student other than the discount available through categories.<?php echo e($permissions['can_edit_extra_discount'] !== true ? ' (You do not have privilege to edit this field)' : ''); ?>" <?php echo e(( $permissions['can_edit_extra_discount'] !== true ? 'disabled' : '' )); ?>>
                                            </div>
                                        </div>
                                        <div class="col-sm-3">
                                            <div class="form-group">
                                                <label>Monthly Fee</label>
                                                <input type="text" class="form-control" id="fee" name="fee" value="" placeholder="Fee" min="0" readonly rel="tooltip" title="Fee for student will be according to the selected current class and category."
                                                        <?php echo e($isInUpdateMode ? 'data-assigned-class-fee=' . $studentEdit->assigned_class_fee : ''); ?>>
                                                <?php if($isInUpdateMode): ?>
                                                    <p class="help-block">Class fee will remain same unless manually changed for the students to whome some fee is assigned.</p>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <!-- Admission information ends -->

                                        <!-- Personal information Starts -->
                                        <div class="col-xs-12">
                                            <legend>Personal Information</legend>
                                        </div>

                                        <div class="col-sm-3 col-sm-push-9">
                                            <div class="form-group">
                                                <img style="max-height: 100px;" id="img_preview" src="<?php echo e(Storage::url( $studentEdit->image ?: 'user_images/avatars/male.png' )); ?>">
                                            </div>
                                            <div>
                                                <input class="show-image-preview" data-target="#img_preview" type="file" accept="image/*" name="image">
                                                <input type="hidden" id="student_image_capture" name="image_capture" value="">
                                            </div>
                                            <div class="text-center" style="margin-top: 10px;">
                                                <button type="button" id="capture_picture_modal" class="btn btn-primary">Capture Picture</button>
                                            </div>
                                        </div>

                                        <div class="col-sm-9 col-sm-pull-3">
                                            <div class="row">
                                                <div class="col-sm-4">
                                                    <div class="form-group">
                                                        <label>Student Name</label>
                                                        <input type="text" class="form-control" name="name" value="<?php echo e(old('name') ?? $studentEdit->name); ?>" placeholder="Student Name">
                                                    </div>
                                                </div>
                                                <div class="col-sm-3">
                                                    <div class="form-group">
                                                        <label>CNIC/B.Form</label>
                                                        <input type="text" class="form-control" name="cnic" value="<?php echo e(old('cnic') ?? $studentEdit->cnic); ?>" minlength="13" maxlength="13" placeholder="CNIC">
                                                    </div>
                                                </div>
                                                <div class="col-sm-2">
                                                    <div class="form-group">
                                                        <label>Gender</label>
                                                        <select class="form-control" name="gender">
                                                            <option value="male" <?php echo e(( ( old('gender') ?? $studentEdit->gender ) == 'male' ? 'selected' : '' )); ?>>Male</option>
                                                            <option value="female" <?php echo e(( ( old('gender') ?? $studentEdit->gender ) == 'female' ? 'selected' : '' )); ?>>Female</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-sm-2">
                                                    <div class="form-group">
                                                        <label>Religion</label>
                                                        <input type="text" class="form-control" name="religion" value="<?php echo e(old('religion') ?? $studentEdit->religion); ?>" placeholder="Religion">
                                                    </div>
                                                </div>
                                                <div class="col-sm-2">
                                                    <div class="form-group">
                                                        <label>Caste</label>
                                                        <input type="text" class="form-control" name="caste" value="<?php echo e(old('caste') ?? $studentEdit->caste); ?>" placeholder="Caste">
                                                    </div>
                                                </div>
                                                <div class="col-sm-3">
                                                    <div class="form-group">
                                                        <label>DOB</label>
                                                        <div class="input-group">
                                                            <input type="text" class="form-control datepicker" name="dob" value="<?php echo e(old('dob') ?? ( !empty($studentEdit->dob) ? $studentEdit->dob->format('d-m-Y') : '' )); ?>" placeholder="Select DOB" data-dateformat="dd-mm-yy">
                                                            <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4">
                                                    <div class="form-group">
                                                        <label>DOB in words</label>
                                                        <textarea class="form-control" name="dob_words" rows="2" placeholder="It will be generated automatically if left empty. If it's not empty, available content will be used instead." rel="tooltip" title="It will be generated automatically if left empty. If it's not empty, available content will be used instead."><?php echo e(old('dob_words') ?? $studentEdit->dob_words); ?></textarea>
                                                        <p class="help-block">It will be generated automatically if left empty. If it contains some content, that will be used instead.</p>
                                                    </div>
                                                </div>
                                                <div class="col-sm-2">
                                                    <div class="form-group">
                                                        <label>Blood Group</label>
                                                        <input type="text" class="form-control" name="blood_group" value="<?php echo e(old('blood_group') ?? $studentEdit->blood_group); ?>" placeholder="Blood Group">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Personal information Ends -->

                                        <!-- Father information Starts -->
                                        <div class="col-xs-12">
                                            <legend>Father Information</legend>
                                        </div>

                                        <div class="col-sm-2">
                                            <div class="form-group">
                                                <label>CNIC</label>
                                                <input type="text" class="form-control father_cnic" name="father_cnic" value="<?php echo e(old('father_cnic') ?? $studentEdit->fatherRecord->cnic ?? ''); ?>" minlength="13" maxlength="13" placeholder="CNIC" rel="tooltip" title="If details regarding provided CNIC already exists, they'll be filled in their respective inputs.">
                                            </div>
                                        </div>
                                        <div class="col-sm-3">
                                            <div class="form-group">
                                                <label>Name</label>
                                                <input type="text" class="form-control" name="father_name" value="<?php echo e(old('father_name') ?? $studentEdit->fatherRecord->name ?? ''); ?>" placeholder="Name">
                                            </div>
                                        </div>
                                        <div class="col-sm-3">
                                            <div class="form-group">
                                                <label>Qualification</label>
                                                <input type="text" class="form-control" name="father_qualification" value="<?php echo e(old('father_qualification') ?? $studentEdit->fatherRecord->qualification ?? ''); ?>" placeholder="Qualification">
                                            </div>
                                        </div>
                                        <div class="col-sm-2">
                                            <div class="form-group">
                                                <label>Mobile</label>
                                                <input type="text" class="form-control" name="father_mobile" value="<?php echo e(old('father_mobile') ?? $studentEdit->fatherRecord->mobile ?? ''); ?>" placeholder="Mobile">
                                            </div>
                                        </div>
                                        <div class="col-sm-2">
                                            <div class="form-group">
                                                <label>SMS Cell</label>
                                                <input type="text" class="form-control" name="father_sms_cell" value="<?php echo e(old('father_sms_cell') ?? $studentEdit->fatherRecord->sms_cell ?? ""); ?>" placeholder="SMS Cell">
                                            </div>
                                        </div>
                                        <div class="col-sm-2">
                                            <div class="form-group">
                                                <label>PTCL</label>
                                                <input type="text" class="form-control" name="father_ptcl" value="<?php echo e(old('father_ptcl') ?? $studentEdit->fatherRecord->ptcl ?? ''); ?>" placeholder="PTCL">
                                            </div>
                                        </div>
                                        <div class="col-sm-2">
                                            <div class="form-group">
                                                <label>Email</label>
                                                <input type="text" class="form-control" name="father_email" value="<?php echo e(old('father_email') ?? $studentEdit->fatherRecord->email ?? ''); ?>" placeholder="Email">
                                            </div>
                                        </div>
                                        <div class="col-sm-3">
                                            <div class="form-group">
                                                <label>Profession</label>
                                                <input type="text" class="form-control" name="father_profession" value="<?php echo e(old('father_profession') ?? $studentEdit->fatherRecord->profession ?? ''); ?>" placeholder="Profession">
                                            </div>
                                        </div>
                                        <div class="col-sm-4">
                                            <div class="form-group">
                                                <label>Job Address</label>
                                                <textarea class="form-control" name="father_job_address" rows="2" placeholder="Father's Job Address"><?php echo e(old('father_job_address') ?? $studentEdit->fatherRecord->job_address ?? ''); ?></textarea>
                                            </div>
                                        </div>
                                        <!-- Father information Ends -->

                                        <!-- Mother Information Starts -->
                                        <div class="col-xs-12">
                                            <legend>Mother Information</legend>
                                        </div>

                                        <div class="col-sm-3">
                                            <div class="form-group">
                                                <label>Name</label>
                                                <input type="text" class="form-control" name="mother_name" value="<?php echo e(old('mother_name') ?? $studentEdit->mother_name); ?>" placeholder="Mother Name">
                                            </div>
                                        </div>
                                        <div class="col-sm-2">
                                            <div class="form-group">
                                                <label>Qualifications</label>
                                                <input type="text" class="form-control" name="mother_qualification" value="<?php echo e(old('mother_qualification') ?? $studentEdit->mother_qualification); ?>" placeholder="Mother Qualifications">
                                            </div>
                                        </div>
                                        <div class="col-sm-2">
                                            <div class="form-group">
                                                <label>Profession</label>
                                                <input type="text" class="form-control" name="mother_profession" value="<?php echo e(old('mother_profession') ?? $studentEdit->mother_profession); ?>" placeholder="Mother Profession">
                                            </div>
                                        </div>
                                        <div class="col-sm-2">
                                            <div class="form-group">
                                                <label>Phone</label>
                                                <input type="text" class="form-control" name="mother_phone" value="<?php echo e(old('mother_phone') ?? $studentEdit->mother_phone); ?>" placeholder="Mother Phone">
                                            </div>
                                        </div>
                                        <div class="col-sm-3">
                                            <div class="form-group">
                                                <label>Job Address</label>
                                                <textarea class="form-control" name="mother_job_address" rows="2" placeholder="Mother's Job Address"><?php echo e(old('mother_job_address') ?? $studentEdit->mother_job_address); ?></textarea>
                                            </div>
                                        </div>
                                        <!-- Mother Information Starts -->

                                        <!-- Address Information Starts -->
                                        <div class="col-xs-12">
                                            <legend>Address Information</legend>
                                        </div>

                                        <div class="col-sm-5">
                                            <div class="form-group">
                                                <label>Home Street Address</label>
                                                <textarea class="form-control" name="home_street_address" rows="2" placeholder="Home Street Address"><?php echo e(old('home_street_address') ?? $studentEdit->home_street_address); ?></textarea>
                                            </div>
                                        </div>
                                        <div class="col-sm-3">
                                            <div class="form-group">
                                                <label>Colony</label>
                                                <input type="text" class="form-control" name="colony" value="<?php echo e(old('colony') ?? $studentEdit->colony); ?>" placeholder="Colony">
                                            </div>
                                        </div>
                                        <div class="col-sm-3">
                                            <div class="form-group">
                                                <label>City</label>
                                                <input type="text" class="form-control" name="city" value="<?php echo e(old('city') ?? $studentEdit->city); ?>" placeholder="City">
                                            </div>
                                        </div>
                                        <!-- Address Information Ends -->

                                        <!-- Other Information Starts -->
                                        <div class="col-xs-12">
                                            <legend>Other Information</legend>
                                        </div>

                                        <div class="col-sm-3">
                                            <div class="form-group">
                                                <label>School Medium</label>
                                                <select class="form-control" name="school_medium_id">
                                                    <option value="">Select School Medium</option>

                                                    <?php $__currentLoopData = $school_mediums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school_medium): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($school_medium->id); ?>" <?php echo e(( ( old('school_medium_id') ?? $studentEdit->school_medium_id ) == $school_medium->id ? 'selected' : '' )); ?>><?php echo e($school_medium->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-sm-4">
                                            <div class="form-group">
                                                <label>Speciality</label>
                                                <input type="text" class="form-control" name="speciality" value="<?php echo e(old('speciality') ?? $studentEdit->speciality); ?>" placeholder="Speciality">
                                            </div>
                                        </div>

                                        <div class="col-sm-5">
                                            <div class="form-group">
                                                <label>Note</label>
                                                <textarea class="form-control" name="note" placeholder="Note" rows="2"><?php echo e(old('note') ?? $studentEdit->note); ?></textarea>
                                            </div>
                                        </div>

                                        <div class="clearfix"></div>

                                        <div class="col-sm-2">
                                            <div class="form-group">
                                                <label>Withdrawn</label>

                                                <?php if( $isInUpdateMode ): ?>
                                                    <div class="bold"><?php echo e(($studentEdit->withdrawn == 0 ? 'Active' : 'Withdrawn')); ?></div>
                                                <?php else: ?>
                                                    <div>
                                                        <label class="radio-inline">
                                                            <input type="radio" name="withdrawn" value="1" <?php echo e(( old('withdrawn') ?? $studentEdit->withdrawn ) == '1'? "checked" : ""); ?>> Yes
                                                        </label>
                                                        <label class="radio-inline">
                                                            <input type="radio" name="withdrawn" value="0" <?php echo e(( old('withdrawn') ?? $studentEdit->withdrawn ) == '0' || ( old('withdrawn') ?? $studentEdit->withdrawn ) == null ? "checked" : ""); ?>> No
                                                        </label>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <!-- Other Information Ends -->

                                        <?php if($isInUpdateMode): ?>
                                        <!-- Student attachments starts -->
                                            <div class="col-xs-12">
                                                <legend class="show_hide_on_click" data-target="#available_attachments" data-hide-text="-" data-show-text="+" data-text-selector="#available_attachments_show_hide_status">Available Student Attachments (<span id="available_attachments_show_hide_status">+</span>)
                                                </legend>
                                            </div>

                                            <div class="col-xs-12">
                                                <div id="available_attachments" class="table-responsive" style="display: none;">
                                                    <table class="table table-striped table-bordered">
                                                        <thead>
                                                            <tr>
                                                                <th>Sr.</th>
                                                                <th>Attachment</th>
                                                                <th>Title</th>
                                                                <th>Action</th>
                                                            </tr>
                                                        </thead>

                                                        <tbody>
                                                            <?php $__currentLoopData = $studentEdit->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td><?php echo e($loop->iteration); ?></td>
                                                                    <td>
                                                                        <a href="<?php echo e(Storage::url($attachment->path)); ?>"><?php echo e($attachment->path); ?></a>
                                                                    </td>
                                                                    <td><?php echo e($attachment->title); ?></td>
                                                                    <td>
                                                                        <a href="<?php echo e(route('dashboard.student_attachment.delete', ['studentAttachment' => $attachment->id])); ?>" class="btn btn-danger btn-xs delete-confirm-model" rel="tooltip" title="Remove this attachment">
                                                                            <i class="fa fa-trash-o"></i>
                                                                        </a>
                                                                    </td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        <?php endif; ?>

                                        <!-- Add student attachments starts -->
                                        <div class="col-xs-12">
                                            <legend class="show_hide_on_click" data-target="#attachments_container" data-hide-text="-" data-show-text="+" data-text-selector="#add_student_attachment_show_hide_status">Add Student Attachments (<span id="add_student_attachment_show_hide_status">+</span>)
                                            </legend>
                                        </div>

                                        <div class="col-xs-12">
                                            <div id="attachments_container" class="table-responsive" style="display: none;">
                                                <table class="table table-striped table-bordered">
                                                    <thead>
                                                        <tr>
                                                            <th>Sr.</th>
                                                            <th>Attachment</th>
                                                            <th>Title</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>

                                                    <tbody>
                                                        
                                                        
                                                        
                                                        
                                                        
                                                        
                                                        
                                                        
                                                        
                                                        
                                                        
                                                        
                                                        
                                                        
                                                    </tbody>
                                                </table>

                                                <div>
                                                    <button type="button" id="add_attachments_btn" class="btn btn-primary" rel="tooltip" title="Add more attachments">
                                                        <i class="fa fa-plus"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Add student attachments ends -->

                                        <!-- Student sibling starts -->
                                        <div class="col-xs-12">
                                            <legend class="show_hide_on_click" data-target="#student_sibling" data-hide-text="-" data-show-text="+" data-text-selector="#student_sibling_show_hide_status">Student's Siblings (<span id="student_sibling_show_hide_status">+</span>)
                                            </legend>
                                        </div>

                                        <div class="col-xs-12">
                                            <div class="table-responsive" id="student_sibling" style="display: none;">
                                                <table class="table table-bordered table-striped siblings_table">
                                                    <thead>
                                                        <tr>
                                                            <th>CNIC</th>
                                                            <th>Name</th>
                                                            <th>Class</th>
                                                            <th>School</th>
                                                            <th>Note</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>

                                                    <tbody>
                                                        <?php if($isInUpdateMode): ?>
                                                            <?php $__currentLoopData = $studentEdit->siblings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sibling): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td>
                                                                        <input type="text" class="form-control" name="siblings_cnic[]" value="<?php echo e($sibling->cnic); ?>">
                                                                    </td>
                                                                    <td>
                                                                        <input type="text" class="form-control" name="siblings_name[]" value="<?php echo e($sibling->name); ?>">
                                                                    </td>
                                                                    <td>
                                                                        <input type="text" class="form-control" name="siblings_class[]" value="<?php echo e($sibling->class); ?>">
                                                                    </td>
                                                                    <td>
                                                                        <input type="text" class="form-control" name="siblings_school[]" value="<?php echo e($sibling->school); ?>">
                                                                    </td>
                                                                    <td>
                                                                        <textarea class="form-control" name="siblings_note[]"><?php echo e($sibling->note); ?></textarea>
                                                                    </td>
                                                                    <td>
                                                                        <button type="button" class="btn btn-danger btn-xs remove_sibling_btn">
                                                                            <i class="fa fa-trash-o"></i>
                                                                        </button>
                                                                    </td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    </tbody>
                                                </table>

                                                <div>
                                                    <button type="button" class="btn btn-primary add_sibling_btn" rel="tooltip" title="Add sibling">
                                                        <i class="fa fa-plus"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Student sibling ends -->

                                        <!-- Fee Assignment starts -->
                                        
                                        <?php if($isInUpdateMode === false): ?>
                                            <div class="col-xs-12">
                                                <legend>Assign fee to student's account alongwith admission</legend>
                                                <p style="font-style: italic">Automatic fee generation will add proper fee to the student's accounts on fixed times and dates, but fee from this page will be added to student's individual accounts alongwith admission.<br>If you want to receive student's monthly fee too, you only need to select the corresponding checkbox and the payable monthly fee will be added to the student's account.</p>

                                                <div class="row">
                                                    <?php $__currentLoopData = $studentFeeTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentFeeType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="col-xs-12 col-sm-4 col-md-3 col-lg-2">
                                                            <input type="hidden" name="student_fee_types[<?php echo e($loop->index); ?>][fee_type_id]" value="<?php echo e($studentFeeType->id); ?>">
                                                            <div class="form-horizontal" style="margin-bottom: 10px;">
                                                                <label><?php echo e($studentFeeType->name); ?>: <small><?php echo e($studentFeeType->fee); ?></small></label>
                                                                <div class="input-group">
																	<span class="input-group-addon">
																		<span class="checkbox">
																			<label>
																			  <input type="checkbox" class="checkbox style-0" name="student_fee_types[<?php echo e($loop->index); ?>][selected]" value="1" <?php echo e(old("student_fee_types[{$loop->index}][selected]", 0) == '1' ? 'checked':''); ?>>
																			  <span></span>
																			</label>
																		</span>
																	</span>
                                                                    
                                                                    <?php if($studentFeeType->id != $student_fee_type_monthly_fee_id): ?>
                                                                        <input class="form-control" type="text" name="student_fee_types[<?php echo e($loop->index); ?>][fee_amount]" value="<?php echo e(old("student_fee_types[{$loop->index}][fee_amount]", ($studentFeeType->fee ?? 0))); ?>">
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>

                                                <div class="text-center">
                                                    <div class="checkbox">
                                                        <label>
                                                            <input type="checkbox" class="checkbox style-0" name="proceed_to_fee_receive" value="1">
                                                            <span>Proceed to fee receive after admission</span>
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                        <!-- Fee Assignment ends -->
                                    </div>
                                </fieldset>

                                <div class="form-actions">
                                    <button type="submit" class="btn btn-primary">
                                        <?php if($isInUpdateMode === false): ?>
                                            Add Student
                                        <?php else: ?>
                                            Update Student
                                        <?php endif; ?>
                                    </button>
                                </div>
                            </form>

                        </div>

                    </div>
                    <!-- end widget content -->
                </div>
                <!-- end widget div -->
            </div>
            <!-- end widget -->
        </article>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                        &times;
                    </button>
                    <h4 class="modal-title" id="myModalLabel">Capture Image</h4>
                </div>
                <div class="modal-body">

                    <div class="row text-center">
                        <div class="col-sm-12">
                            <video id="image_capture_video" autoplay style="width: 100%;"></video>
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default student_image_capture_stop_tracks" data-dismiss="modal">Cancle</button>
                    <button type="button" class="btn btn-primary image_capture_btn" data-dismiss="modal">Capture Image</button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush("body"); ?>
    <script>
        jQuery( function ( $ ) {
            /* Attachment code starts */
            var attachments_container = $( "#attachments_container" );

            var sort_sr_no = function () {
                attachments_container.find( 'tbody tr' ).each( function ( i, d ) {
                    var td = $( d ).find( 'td' )[0];

                    $( td ).text( i + 1 );
                } );
            };

            $( "#add_attachments_btn" ).click( function () {
                var row = '<tr>';
                row += '<td>' + ( attachments_container.find( 'tbody tr' ).length + 1 ) + '</td>';
                row += '<td><input type="file" name="attachments[][file]"></td>';
                row += '<td><input type="text" class="form-control" name="attachments[][title]"></td>';
                row += '<td><button type="button" class="btn btn-danger btn-xs remove_attachment_btn"><i class="fa fa-trash-o"></i></button></td>';
                row += '</tr>';

                attachments_container.find( 'tbody' ).append( row );
            } );

            attachments_container.on( 'click', '.remove_attachment_btn', function () {
                if ( confirm( "Do you really want to remove this attachment?" ) ) {
                    $( this ).parents( 'tr' ).remove();
                    sort_sr_no();
                }
            } );
            /* Attachments code ends */

            /* Siblings code starts */
            $( ".add_sibling_btn" ).click( function () {
                var html = '<tr>\n' +
                    '    <td>\n' +
                    '        <input type="text" class="form-control" name="siblings_cnic[]">\n' +
                    '    </td>\n' +
                    '    <td>\n' +
                    '        <input type="text" class="form-control" name="siblings_name[]">\n' +
                    '    </td>\n' +
                    '    <td>\n' +
                    '        <input type="text" class="form-control" name="siblings_class[]">\n' +
                    '    </td>\n' +
                    '    <td>\n' +
                    '        <input type="text" class="form-control" name="siblings_school[]">\n' +
                    '    </td>\n' +
                    '    <td>\n' +
                    '        <textarea class="form-control" name="siblings_note[]"></textarea>\n' +
                    '    </td>\n' +
                    '    <td>\n' +
                    '        <button type="button" class="btn btn-danger btn-xs remove_sibling_btn">\n' +
                    '            <i class="fa fa-trash-o"></i>\n' +
                    '        </button>\n' +
                    '    </td>\n' +
                    '</tr>';

                $( '.siblings_table tbody' ).append( html );
            } );

            $( '.siblings_table' ).on( 'click', '.remove_sibling_btn', function () {
                $( this ).parents( 'tr' ).remove();
            } );
            /* Siblings code ends */

            /* Get Fee starts */
            var get_fee = function () {
                var link = "<?php echo route('api.get_fee'); ?>",
                    current_class_id = $( "#current_class_id" ).val(),
                    category_id = $( "#category_id" ).val(),
                    fee_input = $( "#fee" ),
                    extra_discount = $( "#extra_discount" ).val(),
                    isInUpdateMode = "<?php echo e($isInUpdateMode == true ? 'true' : 'false'); ?>";

                // changing assigned string true/false to actual true/false
                isInUpdateMode = (isInUpdateMode == 'true' ? true : false);

                fee_input.val( '...' );

                // forming request data that will be sent as parameters to the url
                var requestData = {
                    category_id: category_id
                };
                // if editing, in update mode
                if ( isInUpdateMode ) {
                    requestData.current_class_id = current_class_id;

                    var assignedClassFee = fee_input.data( 'assigned-class-fee' );
                    assignedClassFee = parseInt( assignedClassFee );
                }

                $.get( link, requestData, function ( data ) {

                    var fee = data.fee;

                    // if page is in update mode
                    if ( isInUpdateMode ) {
                        // get absolute value of fee as it can be negative. Because only discount in negative form is given
                        fee = Math.abs( fee );
                        // final fee is obtained by getting subtraction discount obtained from here to the assigned fee
                        fee = assignedClassFee - fee;
                    }

                    fee -= extra_discount;
                    fee = (fee <= 0 ? 0 : fee);
                    fee_input.val( fee );

                } ).fail( function () {
                    fee_input.val( '' );
                } );
            };

            get_fee();

            $( "#current_class_id, #category_id, #extra_discount" ).on( 'change', function () {
                get_fee();
            } );
            /* Get Fee ends */

            /* Getting webcam access starts */
            function webcam_access() {
                var video = $( "#image_capture_video" )[0];

                function capture_picture_modal_click() {
                    if ( navigator.mediaDevices.getUserMedia ) {
                        navigator.mediaDevices.getUserMedia( {video: true} )
                            .then( function ( stream ) {
                                window.studentPictureVideoStream = stream;
                                video.srcObject = stream;

                                $( "#myModal" ).modal( 'show' );
                            } )
                            .catch( function ( error ) {
                                console.log( "Something went wrong!" );
                                alert( "Either you didn't allow this page to open webcam or there is no webcam available" );
                            } );
                    }
                }

                $( "#capture_picture_modal" ).click( function () {
                    capture_picture_modal_click();
                } );

                function stop_tracks() {
                    var tracks = window.studentPictureVideoStream.getTracks();
                    for ( var i = 0; i < tracks.length; i++ ) {
                        tracks[i].stop();
                    }
                }

                $(".student_image_capture_stop_tracks").click(function(){
                    stop_tracks();
                });

                var image_capture = function () {
                    var canvas = document.createElement( 'canvas' ),
                        ctx = canvas.getContext( '2d' ),
                        video_width = video.videoWidth,
                        video_height = video.videoHeight;

                    canvas.width = video_width;
                    canvas.height = video_height;

                    ctx.drawImage( video, 0, 0, video_width, video_height );

                    var image_data = canvas.toDataURL( 'image/png' );
                    $( "#img_preview" ).attr( 'src', image_data );

                    $( "#student_image_capture" ).val( image_data );

                    stop_tracks();
                };

                $( ".image_capture_btn" ).on( 'click', function () {
                    image_capture();
                } );
            }

            webcam_access();
            /* Getting webcam access ends */
        } );
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make("layouts.main", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>