<?php $__env->startSection("breadcrumb"); ?>
    <li>Dashboard</li>
    <li>Attendance</li>
    <li><?php echo e($title); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("page_header"); ?>
    <i class="fa fa-fw fa-table"></i>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.partials.datatable", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection("content"); ?>
    <div class="row">
        <!-- NEW WIDGET START -->
        <article class="col-xs-12 col-sm-7 col-sm-push-5 col-md-7 col-md-push-5 col-lg-8 col-lg-push-4">
            <!-- Widget ID (each widget will need unique ID)-->
            <div class="jarviswidget" id="wid-id-0">
                <header>
                    <span class="widget-icon"> <i class="fa fa-table"></i> </span>
                    <h2>Filter </h2>

                </header>

                <!-- widget div-->
                <div>

                    <!-- widget edit box -->
                    <div class="jarviswidget-editbox">
                        <!-- This area used as dropdown edit box -->
                        <input class="form-control" type="text">
                    </div>
                    <!-- end widget edit box -->

                    <!-- widget content -->
                    <div class="widget-body">
                        <form action="<?php echo e(url()->current()); ?>" method="get">
                            <fieldset>
                                <div class="row">
                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label>Date From</label>
                                            <input type="text" class="form-control datepicker" name="date_from" value="<?php echo e(( !empty($date_from) ? $date_from->format('d-m-Y') : '' )); ?>" placeholder="Date From" data-dateformat="dd-mm-yy">
                                        </div>
                                    </div>

                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label>Date To</label>
                                            <input type="text" class="form-control datepicker" name="date_to" value="<?php echo e(( !empty($date_to) ? $date_to->format('d-m-Y') : '' )); ?>" placeholder="Date To" data-dateformat="dd-mm-yy">
                                        </div>
                                    </div>

                                    <div class="col-sm-4">
                                        <p>Attendance Types</p>
                                        <div class="checkbox">
                                            <?php $__currentLoopData = $student_attendance_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student_attendance_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <label class="checkbox-inline">
                                                    <input type="checkbox" name="student_attendance_type_ids[]" value="<?php echo e($student_attendance_type->id); ?>" <?php echo e(collect($student_attendance_type_ids)->contains($student_attendance_type->id) ? "checked" : ""); ?>> <?php echo e($student_attendance_type->name); ?>

                                                </label>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            </fieldset>

                            <div class="form-actions">
                                <button type="submit" class="btn btn-primary">Filter</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </article>

        <article class="col-xs-12 col-sm-5 col-sm-pull-7 col-md-5 col-md-pull-7 col-lg-4 col-lg-pull-8">
            <!-- Widget ID (each widget will need unique ID)-->
            <div class="jarviswidget" id="wid-id-0">
                <header>
                    <span class="widget-icon"> <i class="fa fa-table"></i> </span>
                    <h2>Student Details </h2>

                </header>

                <!-- widget div-->
                <div>

                    <!-- widget edit box -->
                    <div class="jarviswidget-editbox">
                        <!-- This area used as dropdown edit box -->
                        <input class="form-control" type="text">
                    </div>
                    <!-- end widget edit box -->

                    <!-- widget content -->
                    <div class="widget-body no-padding">

                        <div>
                            <img src="<?php echo e(Storage::url($student->image)); ?>" alt="<?php echo e($student->name); ?>" class="img-responsive center-block" style="max-height: 150px;">
                        </div>

                        <table class="table table-bordered table-striped">
                            <tbody>
                                <tr>
                                    <th>PIN</th>
                                    <td><?php echo e($student->pin); ?></td>
                                </tr>
                                <tr>
                                    <th>Name</th>
                                    <td><?php echo e($student->name); ?></td>
                                </tr>
                                <tr>
                                    <th>Father's Name</th>
                                    <td><?php echo e($student->fatherRecord->name ?? ''); ?></td>
                                </tr>
                                <tr>
                                    <th>Branch</th>
                                    <td><?php echo e($student->branch->name ?? ''); ?></td>
                                </tr>
                                <tr>
                                    <th>Class</th>
                                    <td><?php echo e($student->currentClass->name ?? ''); ?></td>
                                </tr>
                                <tr>
                                    <th>Section</th>
                                    <td><?php echo e($student->section->name ?? ''); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </article>

        <article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <!-- Widget ID (each widget will need unique ID)-->
            <div class="jarviswidget" id="wid-id-1">
                <header>
                    <span class="widget-icon"> <i class="fa fa-table"></i> </span>
                    <h2>Student Attendances </h2>

                </header>

                <!-- widget div-->
                <div>

                    <!-- widget edit box -->
                    <div class="jarviswidget-editbox">
                        <!-- This area used as dropdown edit box -->
                        <input class="form-control" type="text">
                    </div>
                    <!-- end widget edit box -->

                    <!-- widget content -->
                    <div class="widget-body no-padding">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped dtable" data-datatable-message-top="<?php $__currentLoopData = $student_attendance_statistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $attendance_statistic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($k); ?>: <?php echo e($attendance_statistic); ?><?php echo e(( $loop->last ? "" : ", " )); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>" data-datatable-message-bottom="<?php $__currentLoopData = $student_attendance_statistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $attendance_statistic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($k); ?>: <?php echo e($attendance_statistic); ?><?php echo e(( $loop->last ? "" : ", " )); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>">
                                <thead>
                                    <tr>
                                        <th>Attendance Date</th>
                                        <th>Attendance Type</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php $__currentLoopData = $student_attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student_attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($student_attendance->attendance_date->format('d-m-Y')); ?></td>
                                            <td><?php echo e($student_attendance->studentAttendanceType->name); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>

                                <tfoot>
                                    <tr>
                                        <th colspan="2" class="text-center">
                                            <?php $__currentLoopData = $student_attendance_statistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $attendance_statistic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($k); ?>: <?php echo e($attendance_statistic); ?><?php echo e(( $loop->last ? "" : ", " )); ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </article>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.main", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>